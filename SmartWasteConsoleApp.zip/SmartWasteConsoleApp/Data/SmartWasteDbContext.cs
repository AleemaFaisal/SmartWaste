﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.Data;

public partial class SmartWasteDbContext : DbContext
{
    public SmartWasteDbContext()
    {
    }

    public SmartWasteDbContext(DbContextOptions<SmartWasteDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Area> Areas { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Citizen> Citizens { get; set; }

    public virtual DbSet<Collection> Collections { get; set; }

    public virtual DbSet<Complaint> Complaints { get; set; }

    public virtual DbSet<Operator> Operators { get; set; }

    public virtual DbSet<Route> Routes { get; set; }

    public virtual DbSet<TransactionRecord> TransactionRecords { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserRole> UserRoles { get; set; }

    public virtual DbSet<VwActiveComplaint> VwActiveComplaints { get; set; }

    public virtual DbSet<VwCitizenProfile> VwCitizenProfiles { get; set; }

    public virtual DbSet<VwLatestStockByCategory> VwLatestStockByCategories { get; set; }

    public virtual DbSet<VwOperatorCollectionPoint> VwOperatorCollectionPoints { get; set; }

    public virtual DbSet<VwOperatorPerformance> VwOperatorPerformances { get; set; }

    public virtual DbSet<VwPartitionStatistic> VwPartitionStatistics { get; set; }

    public virtual DbSet<VwTransactionSummary> VwTransactionSummaries { get; set; }

    public virtual DbSet<VwWarehouseInventory> VwWarehouseInventories { get; set; }

    public virtual DbSet<Warehouse> Warehouses { get; set; }

    public virtual DbSet<WarehouseStock> WarehouseStocks { get; set; }

    public virtual DbSet<WasteListing> WasteListings { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer(
            "Server=localhost;Database=SmartWasteDB;User Id=sa;Password=mak@1234;TrustServerCertificate=True;Connection Timeout=60;Pooling=true;Max Pool Size=100;MultipleActiveResultSets=True;",
            sqlServerOptions => sqlServerOptions
                .EnableRetryOnFailure(
                    maxRetryCount: 5,
                    maxRetryDelay: TimeSpan.FromSeconds(30),
                    errorNumbersToAdd: null)
                .CommandTimeout(120));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Area>(entity =>
        {
            entity.HasKey(e => e.AreaId).HasName("PK__Area__70B82028BFCC5748");

            entity.ToTable("Area", "WasteManagement");

            entity.HasIndex(e => new { e.AreaName, e.City }, "UQ_Area").IsUnique();

            entity.Property(e => e.AreaId).HasColumnName("AreaID");
            entity.Property(e => e.AreaName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.CategoryId).HasName("PK__Category__19093A2B4453B83D");

            entity.ToTable("Category", "WasteManagement", tb => tb.HasTrigger("trg_UpdateListingPrices"));

            entity.HasIndex(e => e.CategoryName, "UQ__Category__8517B2E08D91FB56").IsUnique();

            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.BasePricePerKg).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.CategoryName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Description).HasColumnType("text");
        });

        modelBuilder.Entity<Citizen>(entity =>
        {
            entity.HasKey(e => e.CitizenId).HasName("PK__Citizen__6E49FBECAAA4D2ED");

            entity.ToTable("Citizen", "WasteManagement");

            entity.HasIndex(e => e.AreaId, "IX_Citizen_AreaID");

            entity.Property(e => e.CitizenId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("CitizenID");
            entity.Property(e => e.Address)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.AreaId).HasColumnName("AreaID");
            entity.Property(e => e.FullName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.Area).WithMany(p => p.Citizens)
                .HasForeignKey(d => d.AreaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Citizen_Area");

            entity.HasOne(d => d.CitizenNavigation).WithOne(p => p.Citizen)
                .HasForeignKey<Citizen>(d => d.CitizenId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Citizen_User");
        });

        modelBuilder.Entity<Collection>(entity =>
        {
            entity.HasKey(e => new { e.CollectionId, e.CollectedDate });

            entity.ToTable("Collection", "WasteManagement", tb => tb.HasTrigger("trg_Collection_UpdateStatus"));

            entity.HasIndex(e => new { e.WarehouseId, e.CollectedDate }, "IX_Collection_Analytics");

            entity.HasIndex(e => new { e.OperatorId, e.CollectedDate }, "IX_Collection_OperatorID");

            entity.HasIndex(e => new { e.WarehouseId, e.CollectedDate }, "IX_Collection_WarehouseID");

            entity.Property(e => e.CollectionId)
                .ValueGeneratedOnAdd()
                .HasColumnName("CollectionID");
            entity.Property(e => e.CollectedDate).HasColumnType("datetime");
            entity.Property(e => e.CollectedWeight).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.IsVerified).HasDefaultValue(false);
            entity.Property(e => e.ListingId).HasColumnName("ListingID");
            entity.Property(e => e.OperatorId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("OperatorID");
            entity.Property(e => e.PhotoProof)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");

            entity.HasOne(d => d.Operator).WithMany(p => p.Collections)
                .HasForeignKey(d => d.OperatorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Collection_Operator");

            entity.HasOne(d => d.Warehouse).WithMany(p => p.Collections)
                .HasForeignKey(d => d.WarehouseId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Collection_Warehouse");
        });

        modelBuilder.Entity<Complaint>(entity =>
        {
            entity.HasKey(e => e.ComplaintId).HasName("PK__Complain__740D89AFAA2DB63F");

            entity.ToTable("Complaint", "WasteManagement");

            entity.HasIndex(e => e.CreatedAt, "IX_Complaint_Open").HasFilter("([Status] IN ('Open', 'In Progress'))");

            entity.Property(e => e.ComplaintId).HasColumnName("ComplaintID");
            entity.Property(e => e.CitizenId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("CitizenID");
            entity.Property(e => e.ComplaintType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).HasColumnType("text");
            entity.Property(e => e.OperatorId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("OperatorID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValue("Open");

            entity.HasOne(d => d.Citizen).WithMany(p => p.Complaints)
                .HasForeignKey(d => d.CitizenId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Complaint_Citizen");

            entity.HasOne(d => d.Operator).WithMany(p => p.Complaints)
                .HasForeignKey(d => d.OperatorId)
                .HasConstraintName("FK_Complaint_Operator");
        });

        modelBuilder.Entity<Operator>(entity =>
        {
            entity.HasKey(e => e.OperatorId).HasName("PK__Operator__7BB12F8ED869DD1B");

            entity.ToTable("Operator", "WasteManagement");

            entity.HasIndex(e => e.RouteId, "IX_Operator_RouteID");

            entity.HasIndex(e => e.WarehouseId, "IX_Operator_WarehouseID");

            entity.Property(e => e.OperatorId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("OperatorID");
            entity.Property(e => e.FullName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RouteId).HasColumnName("RouteID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValue("Available");
            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");

            entity.HasOne(d => d.OperatorNavigation).WithOne(p => p.Operator)
                .HasForeignKey<Operator>(d => d.OperatorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Operator_User");

            entity.HasOne(d => d.Route).WithMany(p => p.Operators)
                .HasForeignKey(d => d.RouteId)
                .HasConstraintName("FK_Operator_Route");

            entity.HasOne(d => d.Warehouse).WithMany(p => p.Operators)
                .HasForeignKey(d => d.WarehouseId)
                .HasConstraintName("FK_Operator_Warehouse");
        });

        modelBuilder.Entity<Route>(entity =>
        {
            entity.HasKey(e => e.RouteId).HasName("PK__Route__80979AAD88EE35DC");

            entity.ToTable("Route", "WasteManagement");

            entity.Property(e => e.RouteId).HasColumnName("RouteID");
            entity.Property(e => e.AreaId).HasColumnName("AreaID");
            entity.Property(e => e.RouteName)
                .HasMaxLength(255)
                .IsUnicode(false);

            entity.HasOne(d => d.Area).WithMany(p => p.Routes)
                .HasForeignKey(d => d.AreaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Route_Area");
        });

        modelBuilder.Entity<TransactionRecord>(entity =>
        {
            entity.HasKey(e => new { e.TransactionId, e.TransactionDate });

            entity.ToTable("TransactionRecord", "WasteManagement");

            entity.HasIndex(e => new { e.CitizenId, e.TransactionDate }, "IX_Transaction_CitizenID");

            entity.HasIndex(e => new { e.PaymentStatus, e.TransactionDate }, "IX_Transaction_Status_Date");

            entity.HasIndex(e => new { e.VerificationCode, e.TransactionDate }, "UQ_Transaction_VerificationCode")
                .IsUnique()
                .HasFilter("([VerificationCode] IS NOT NULL)");

            entity.Property(e => e.TransactionId)
                .ValueGeneratedOnAdd()
                .HasColumnName("TransactionID");
            entity.Property(e => e.TransactionDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CitizenId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("CitizenID");
            entity.Property(e => e.OperatorId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("OperatorID");
            entity.Property(e => e.PaymentMethod)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PaymentStatus)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValue("Pending");
            entity.Property(e => e.TotalAmount).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.VerificationCode)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.HasOne(d => d.Citizen).WithMany(p => p.TransactionRecords)
                .HasForeignKey(d => d.CitizenId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Transaction_Citizen");

            entity.HasOne(d => d.Operator).WithMany(p => p.TransactionRecords)
                .HasForeignKey(d => d.OperatorId)
                .HasConstraintName("FK_Transaction_Operator");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__Users__1788CCACB65983B0");

            entity.ToTable("Users", "WasteManagement", tb => tb.HasTrigger("trg_Users_DeleteCascade"));

            entity.HasIndex(e => e.RoleId, "IX_Users_RoleID");

            entity.Property(e => e.UserId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("UserID");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PasswordHash)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.RoleId).HasColumnName("RoleID");

            entity.HasOne(d => d.Role).WithMany(p => p.Users)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Users_Role");
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__UserRole__8AFACE3AFE5602D2");

            entity.ToTable("UserRole", "WasteManagement");

            entity.HasIndex(e => e.RoleName, "UQ__UserRole__8A2B616024ED7107").IsUnique();

            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwActiveComplaint>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_ActiveComplaints", "WasteManagement");

            entity.Property(e => e.AreaName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CitizenId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("CitizenID");
            entity.Property(e => e.CitizenName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.ComplaintId).HasColumnName("ComplaintID");
            entity.Property(e => e.ComplaintType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedAt).HasColumnType("datetime");
            entity.Property(e => e.Description).HasColumnType("text");
            entity.Property(e => e.OperatorId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("OperatorID");
            entity.Property(e => e.OperatorName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RouteName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwCitizenProfile>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_CitizenProfile", "WasteManagement");

            entity.Property(e => e.Address)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.AreaId).HasColumnName("AreaID");
            entity.Property(e => e.AreaName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CitizenId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("CitizenID");
            entity.Property(e => e.City)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FullName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.MemberSince).HasColumnType("datetime");
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwLatestStockByCategory>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_LatestStockByCategory", "WasteManagement");

            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.CategoryName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");
        });

        modelBuilder.Entity<VwOperatorCollectionPoint>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_OperatorCollectionPoints", "WasteManagement");

            entity.Property(e => e.Address)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.AreaName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CategoryName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CitizenId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("CitizenID");
            entity.Property(e => e.CitizenName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.EstimatedPrice).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.ListingId).HasColumnName("ListingID");
            entity.Property(e => e.OperatorId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("OperatorID");
            entity.Property(e => e.OperatorName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RouteId).HasColumnName("RouteID");
            entity.Property(e => e.RouteName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.VerificationCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Weight).HasColumnType("decimal(10, 2)");
        });

        modelBuilder.Entity<VwOperatorPerformance>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_OperatorPerformance", "WasteManagement");

            entity.Property(e => e.FullName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.OperatorId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("OperatorID");
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RouteId).HasColumnName("RouteID");
            entity.Property(e => e.TotalCollectedAmount).HasColumnType("decimal(38, 2)");
            entity.Property(e => e.TotalCollectedWeight).HasColumnType("decimal(38, 2)");
            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");
        });

        modelBuilder.Entity<VwPartitionStatistic>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_PartitionStatistics", "WasteManagement");

            entity.Property(e => e.RangeBoundary)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.SizeMb)
                .HasColumnType("numeric(26, 6)")
                .HasColumnName("SizeMB");
            entity.Property(e => e.TableName).HasMaxLength(128);
        });

        modelBuilder.Entity<VwTransactionSummary>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_TransactionSummary", "WasteManagement");

            entity.Property(e => e.CitizenName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.OperatorName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.PaymentStatus)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TotalAmount).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.TotalWeight).HasColumnType("decimal(38, 2)");
            entity.Property(e => e.TransactionDate).HasColumnType("datetime");
            entity.Property(e => e.TransactionId).HasColumnName("TransactionID");
        });

        modelBuilder.Entity<VwWarehouseInventory>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_WarehouseInventory", "WasteManagement");

            entity.Property(e => e.AreaName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");
            entity.Property(e => e.WarehouseName)
                .HasMaxLength(255)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Warehouse>(entity =>
        {
            entity.HasKey(e => e.WarehouseId).HasName("PK__Warehous__2608AFD9093ADD7B");

            entity.ToTable("Warehouse", "WasteManagement");

            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");
            entity.Property(e => e.Address)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.AreaId).HasColumnName("AreaID");
            entity.Property(e => e.CurrentInventory).HasDefaultValue(0.0);
            entity.Property(e => e.WarehouseName)
                .HasMaxLength(255)
                .IsUnicode(false);

            entity.HasOne(d => d.Area).WithMany(p => p.Warehouses)
                .HasForeignKey(d => d.AreaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Warehouse_Area");
        });

        modelBuilder.Entity<WarehouseStock>(entity =>
        {
            entity.HasKey(e => new { e.WarehouseId, e.CategoryId });

            entity.ToTable("WarehouseStock", "WasteManagement", tb => tb.HasTrigger("trg_WarehouseStock_UpdateInventory"));

            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");
            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.LastUpdated)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Category).WithMany(p => p.WarehouseStocks)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_WarehouseStock_Category");

            entity.HasOne(d => d.Warehouse).WithMany(p => p.WarehouseStocks)
                .HasForeignKey(d => d.WarehouseId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_WarehouseStock_Warehouse");
        });

        modelBuilder.Entity<WasteListing>(entity =>
        {
            entity.HasKey(e => new { e.ListingId, e.CreatedAt });

            entity.ToTable("WasteListing", "WasteManagement", tb => tb.HasTrigger("trg_WasteListing_AutoCalculatePrice"));

            entity.HasIndex(e => new { e.CategoryId, e.CreatedAt }, "IX_WasteListing_CategoryID");

            entity.HasIndex(e => new { e.CitizenId, e.CreatedAt }, "IX_WasteListing_CitizenID");

            entity.HasIndex(e => new { e.CitizenId, e.CreatedAt }, "IX_WasteListing_Pending").HasFilter("([Status]='Pending')");

            entity.HasIndex(e => new { e.Status, e.CreatedAt }, "IX_WasteListing_Status_Date");

            entity.Property(e => e.ListingId)
                .ValueGeneratedOnAdd()
                .HasColumnName("ListingID");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.CitizenId)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("CitizenID");
            entity.Property(e => e.EstimatedPrice).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValue("Pending");
            entity.Property(e => e.TransactionId).HasColumnName("TransactionID");
            entity.Property(e => e.Weight).HasColumnType("decimal(10, 2)");

            entity.HasOne(d => d.Category).WithMany(p => p.WasteListings)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_WasteListing_Category");

            entity.HasOne(d => d.Citizen).WithMany(p => p.WasteListings)
                .HasForeignKey(d => d.CitizenId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_WasteListing_Citizen");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
