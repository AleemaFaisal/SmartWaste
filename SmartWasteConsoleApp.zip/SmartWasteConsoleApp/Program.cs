using SmartWasteConsoleApp.Factory;
using SmartWasteConsoleApp.Utilities;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp
{
    class Program
    {
        static string currentUserId = string.Empty;
        static string currentUserRole = string.Empty;

        // Helper method to generate password hashes
        static void GeneratePasswordHashes()
        {
            var authService = ServiceFactory.GetAuthService();
            Console.WriteLine("=== Password Hashes ===");
            Console.WriteLine($"admin123: {authService.HashPassword("admin123")}");
            Console.WriteLine($"citizen123: {authService.HashPassword("citizen123")}");
            Console.WriteLine($"operator123: {authService.HashPassword("operator123")}");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        static void Main(string[] args)
        {
            // Uncomment this line to generate password hashes
            // GeneratePasswordHashes();
            // return;

            // // Quick database connectivity test
            // QuickDBTest.TestConnection();
            // return;

            bool running = true;

            while (running)
            {
                ConsoleUI.PrintHeader("Smart Waste Management System");
                Console.WriteLine($"Current Implementation: {ServiceFactory.GetCurrentImplementationName()}");
                Console.WriteLine();

                var options = new[]
                {
                    "Login as Citizen",
                    "Login as Operator",
                    "Login as Government Regulator",
                    "Register as Citizen",
                    "Switch BLL Implementation",
                    "Exit"
                };

                int choice = ConsoleUI.ShowMenu("Main Menu", options);

                switch (choice)
                {
                    case 1:
                        LoginCitizen();
                        break;
                    case 2:
                        LoginOperator();
                        break;
                    case 3:
                        LoginGovernment();
                        break;
                    case 4:
                        RegisterCitizen();
                        break;
                    case 5:
                        SwitchImplementation();
                        break;
                    case 6:
                        running = false;
                        break;
                    default:
                        ConsoleUI.PrintError("Invalid choice. Please try again.");
                        ConsoleUI.PressAnyKeyToContinue();
                        break;
                }
            }

            Console.WriteLine("Thank you for using Smart Waste Management System!");
        }

        static void SwitchImplementation()
        {
            ConsoleUI.PrintHeader("Switch BLL Implementation");

            var options = new[]
            {
                "Entity Framework (LINQ)",
                "Stored Procedures"
            };

            int choice = ConsoleUI.ShowMenu("Select Implementation", options);

            if (choice == 1)
            {
                ServiceFactory.CurrentImplementation = ImplementationType.EntityFramework;
                ConsoleUI.PrintSuccess("Switched to Entity Framework implementation");
            }
            else if (choice == 2)
            {
                ServiceFactory.CurrentImplementation = ImplementationType.StoredProcedure;
                ConsoleUI.PrintSuccess("Switched to Stored Procedure implementation");
            }
            else
            {
                ConsoleUI.PrintError("Invalid choice");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void RegisterCitizen()
        {
            ConsoleUI.PrintHeader("Register as Citizen");

            try
            {
                string cnic = ConsoleUI.ReadInput("Enter CNIC (format: XXXXX-XXXXXXX-X)");
                if (!InputValidator.ValidateCNIC(cnic))
                {
                    ConsoleUI.PrintError("Invalid CNIC format");
                    ConsoleUI.PressAnyKeyToContinue();
                    return;
                }

                string password = ConsoleUI.ReadPassword("Enter Password");
                string fullName = ConsoleUI.ReadInput("Enter Full Name");
                string phoneNumber = ConsoleUI.ReadInput("Enter Phone Number");

                // Show areas
                var govService = ServiceFactory.GetGovernmentService();
                var areas = govService.GetAllAreas();

                Console.WriteLine("\nAvailable Areas:");
                foreach (var area in areas)
                {
                    Console.WriteLine($"{area.AreaId}. {area.AreaName}, {area.City}");
                }

                string areaIdStr = ConsoleUI.ReadInput("Enter Area ID");
                if (!InputValidator.ValidateInt(areaIdStr, out int areaId))
                {
                    ConsoleUI.PrintError("Invalid Area ID");
                    ConsoleUI.PressAnyKeyToContinue();
                    return;
                }

                string address = ConsoleUI.ReadInput("Enter Address");

                var citizenService = ServiceFactory.GetCitizenService();
                bool result = citizenService.RegisterCitizen(cnic, password, fullName, phoneNumber, areaId, address, out string message);

                if (result)
                {
                    ConsoleUI.PrintSuccess(message);
                }
                else
                {
                    ConsoleUI.PrintError(message);
                }
            }
            catch (Exception ex)
            {
                ConsoleUI.PrintError($"Error: {ex.Message}");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void LoginCitizen()
        {
            ConsoleUI.PrintHeader("Citizen Login");

            string cnic = ConsoleUI.ReadInput("Enter CNIC");
            string password = ConsoleUI.ReadPassword("Enter Password");

            // Authenticate user
            var authService = ServiceFactory.GetAuthService();
            var (success, user, roleName, message) = authService.AuthenticateUser(cnic, password);

            if (!success)
            {
                ConsoleUI.PrintError(message);
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            // Check if user is a citizen
            if (roleName != "Citizen")
            {
                ConsoleUI.PrintError("This login is for Citizens only. Please use the appropriate login option.");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            currentUserId = cnic;
            currentUserRole = roleName;

            ConsoleUI.PrintSuccess($"Welcome, {roleName}!");
            System.Threading.Thread.Sleep(1000);

            CitizenDashboard();
        }

        static void LoginOperator()
        {
            ConsoleUI.PrintHeader("Operator Login");

            string cnic = ConsoleUI.ReadInput("Enter CNIC");
            string password = ConsoleUI.ReadPassword("Enter Password");

            // Authenticate user
            var authService = ServiceFactory.GetAuthService();
            var (success, user, roleName, message) = authService.AuthenticateUser(cnic, password);

            if (!success)
            {
                ConsoleUI.PrintError(message);
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            // Check if user is an operator
            if (roleName != "Operator")
            {
                ConsoleUI.PrintError("This login is for Operators only. Please use the appropriate login option.");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            currentUserId = cnic;
            currentUserRole = roleName;

            ConsoleUI.PrintSuccess($"Welcome, {roleName}!");
            System.Threading.Thread.Sleep(1000);

            OperatorDashboard();
        }

        static void LoginGovernment()
        {
            ConsoleUI.PrintHeader("Government Regulator Login");

            string cnic = ConsoleUI.ReadInput("Enter CNIC");
            string password = ConsoleUI.ReadPassword("Enter Password");

            // Authenticate user
            var authService = ServiceFactory.GetAuthService();
            var (success, user, roleName, message) = authService.AuthenticateUser(cnic, password);

            if (!success)
            {
                ConsoleUI.PrintError(message);
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            // Check if user is admin (government regulator)
            if (roleName != "Admin")
            {
                ConsoleUI.PrintError("This login is for Government Regulators only. Please use the appropriate login option.");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            currentUserId = cnic;
            currentUserRole = roleName;

            ConsoleUI.PrintSuccess($"Welcome, Government Regulator!");
            System.Threading.Thread.Sleep(1000);

            GovernmentDashboard();
        }

        static void CitizenDashboard()
        {
            bool running = true;
            var citizenService = ServiceFactory.GetCitizenService();

            while (running)
            {
                ConsoleUI.PrintHeader($"Citizen Dashboard - {currentUserId}");
                Console.WriteLine($"Implementation: {ServiceFactory.GetCurrentImplementationName()}");
                Console.WriteLine();

                var options = new[]
                {
                    "View My Profile",
                    "Create Waste Listing",
                    "View My Listings",
                    "Publish Listings (Request Pickup)",
                    "Get Price Estimation",
                    "View My Transactions",
                    "Logout"
                };

                int choice = ConsoleUI.ShowMenu("Citizen Menu", options);

                try
                {
                    switch (choice)
                    {
                        case 1:
                            ViewCitizenProfile(citizenService);
                            break;
                        case 2:
                            CreateWasteListing(citizenService);
                            break;
                        case 3:
                            ViewMyListings(citizenService);
                            break;
                        case 4:
                            PublishListings(citizenService);
                            break;
                        case 5:
                            GetPriceEstimation(citizenService);
                            break;
                        case 6:
                            ViewMyTransactions(citizenService);
                            break;
                        case 7:
                            running = false;
                            break;
                        default:
                            ConsoleUI.PrintError("Invalid choice");
                            ConsoleUI.PressAnyKeyToContinue();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    ConsoleUI.PrintError($"Error: {ex.Message}");
                    ConsoleUI.PressAnyKeyToContinue();
                }
            }
        }

        static void ViewCitizenProfile(ICitizenService service)
        {
            ConsoleUI.PrintHeader("My Profile");

            var profile = service.GetProfile(currentUserId);

            if (profile != null)
            {
                Console.WriteLine($"CNIC: {profile.CitizenId}");
                Console.WriteLine($"Name: {profile.FullName}");
                Console.WriteLine($"Phone: {profile.PhoneNumber}");
                Console.WriteLine($"Address: {profile.Address}");
                Console.WriteLine($"Area: {profile.AreaName}, {profile.City}");
                Console.WriteLine($"Member Since: {profile.MemberSince}");
            }
            else
            {
                ConsoleUI.PrintWarning("Profile not found");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void CreateWasteListing(ICitizenService service)
        {
            ConsoleUI.PrintHeader("Create Waste Listing");

            // Show categories
            var govService = ServiceFactory.GetGovernmentService();
            var categories = govService.GetAllCategories();

            Console.WriteLine("Available Categories:");
            foreach (var cat in categories)
            {
                Console.WriteLine($"{cat.CategoryId}. {cat.CategoryName} - Rs.{cat.BasePricePerKg}/kg");
            }

            Console.WriteLine();
            string categoryIdStr = ConsoleUI.ReadInput("Enter Category ID");
            if (!InputValidator.ValidatePositiveInt(categoryIdStr, out int categoryId))
            {
                ConsoleUI.PrintError("Invalid Category ID");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            string weightStr = ConsoleUI.ReadInput("Enter Weight (kg)");
            if (!InputValidator.ValidatePositiveDecimal(weightStr, out decimal weight))
            {
                ConsoleUI.PrintError("Invalid weight");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            bool result = service.CreateWasteListing(currentUserId, categoryId, weight, out int listingId, out decimal estimatedPrice, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
                ConsoleUI.PrintInfo($"Listing ID: {listingId}");
                ConsoleUI.PrintInfo($"Estimated Price: Rs.{estimatedPrice:F2}");
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ViewMyListings(ICitizenService service)
        {
            ConsoleUI.PrintHeader("My Waste Listings");

            var listings = service.GetMyListings(currentUserId);

            if (listings.Count > 0)
            {
                ConsoleUI.PrintTable(listings,
                    ("ID", l => l.ListingId.ToString()),
                    ("Category", l => l.Category?.CategoryName ?? "N/A"),
                    ("Weight (kg)", l => l.Weight.ToString("F2")),
                    ("Price (Rs)", l => (l.EstimatedPrice ?? 0).ToString("F2")),
                    ("Status", l => l.Status ?? "N/A"),
                    ("Date", l => l.CreatedAt.ToString("yyyy-MM-dd"))
                );

                Console.WriteLine($"\nTotal Listings: {listings.Count}");
            }
            else
            {
                ConsoleUI.PrintWarning("No listings found");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void PublishListings(ICitizenService service)
        {
            ConsoleUI.PrintHeader("Publish Listings");

            var listings = service.GetMyListings(currentUserId)
                .Where(l => l.Status == "Pending" && l.TransactionId == null)
                .ToList();

            if (listings.Count == 0)
            {
                ConsoleUI.PrintWarning("No pending listings available to publish");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            Console.WriteLine("Pending Listings:");
            foreach (var listing in listings)
            {
                Console.WriteLine($"{listing.ListingId}. {listing.Category?.CategoryName} - {listing.Weight}kg - Rs.{listing.EstimatedPrice:F2}");
            }

            Console.WriteLine();
            string listingIdsStr = ConsoleUI.ReadInput("Enter Listing IDs to publish (comma-separated)");

            var listingIds = listingIdsStr.Split(',')
                .Select(s => s.Trim())
                .Where(s => int.TryParse(s, out _))
                .Select(int.Parse)
                .ToList();

            if (listingIds.Count == 0)
            {
                ConsoleUI.PrintError("No valid listing IDs provided");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            bool result = service.PublishListing(currentUserId, listingIds, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void GetPriceEstimation(ICitizenService service)
        {
            ConsoleUI.PrintHeader("Price Estimation");

            var govService = ServiceFactory.GetGovernmentService();
            var categories = govService.GetAllCategories();

            Console.WriteLine("Available Categories:");
            foreach (var cat in categories)
            {
                Console.WriteLine($"{cat.CategoryId}. {cat.CategoryName} - Rs.{cat.BasePricePerKg}/kg");
            }

            Console.WriteLine();
            string categoryIdStr = ConsoleUI.ReadInput("Enter Category ID");
            if (!InputValidator.ValidatePositiveInt(categoryIdStr, out int categoryId))
            {
                ConsoleUI.PrintError("Invalid Category ID");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            string weightStr = ConsoleUI.ReadInput("Enter Weight (kg)");
            if (!InputValidator.ValidatePositiveDecimal(weightStr, out decimal weight))
            {
                ConsoleUI.PrintError("Invalid weight");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            decimal estimatedPrice = service.GetPriceEstimation(categoryId, weight);
            ConsoleUI.PrintInfo($"Estimated Price: Rs.{estimatedPrice:F2}");

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ViewMyTransactions(ICitizenService service)
        {
            ConsoleUI.PrintHeader("My Transactions");

            var transactions = service.GetMyTransactions(currentUserId);

            if (transactions.Count > 0)
            {
                ConsoleUI.PrintTable(transactions,
                    ("Transaction ID", t => t.TransactionId.ToString()),
                    ("Amount (Rs)", t => t.TotalAmount.ToString("F2")),
                    ("Status", t => t.PaymentStatus ?? ""),
                    ("Items", t => (t.ItemCount ?? 0).ToString()),
                    ("Date", t => t.TransactionDate.ToString("yyyy-MM-dd"))
                );
            }
            else
            {
                ConsoleUI.PrintWarning("No transactions found");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void OperatorDashboard()
        {
            bool running = true;
            var operatorService = ServiceFactory.GetOperatorService();

            while (running)
            {
                ConsoleUI.PrintHeader($"Operator Dashboard - {currentUserId}");
                Console.WriteLine($"Implementation: {ServiceFactory.GetCurrentImplementationName()}");
                Console.WriteLine();

                var options = new[]
                {
                    "View My Profile",
                    "View Collection Points on Route",
                    "Perform Collection",
                    "View My Performance",
                    "Update My Status",
                    "Logout"
                };

                int choice = ConsoleUI.ShowMenu("Operator Menu", options);

                try
                {
                    switch (choice)
                    {
                        case 1:
                            ViewOperatorProfile(operatorService);
                            break;
                        case 2:
                            ViewCollectionPoints(operatorService);
                            break;
                        case 3:
                            PerformCollection(operatorService);
                            break;
                        case 4:
                            ViewOperatorPerformance(operatorService);
                            break;
                        case 5:
                            UpdateOperatorStatus(operatorService);
                            break;
                        case 6:
                            running = false;
                            break;
                        default:
                            ConsoleUI.PrintError("Invalid choice");
                            ConsoleUI.PressAnyKeyToContinue();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    ConsoleUI.PrintError($"Error: {ex.Message}");
                    ConsoleUI.PressAnyKeyToContinue();
                }
            }
        }

        static void ViewOperatorProfile(IOperatorService service)
        {
            ConsoleUI.PrintHeader("My Profile");

            var profile = service.GetProfile(currentUserId);

            if (profile != null)
            {
                Console.WriteLine($"Operator ID: {profile.OperatorId}");
                Console.WriteLine($"Name: {profile.FullName}");
                Console.WriteLine($"Phone: {profile.PhoneNumber}");
                Console.WriteLine($"Status: {profile.Status}");
                Console.WriteLine($"Route: {profile.Route?.RouteName ?? "Not Assigned"}");
                Console.WriteLine($"Warehouse: {profile.Warehouse?.WarehouseName ?? "Not Assigned"}");
            }
            else
            {
                ConsoleUI.PrintWarning("Profile not found");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ViewCollectionPoints(IOperatorService service)
        {
            ConsoleUI.PrintHeader("Collection Points on My Route");

            var collectionPoints = service.GetCollectionPoints(currentUserId);

            if (collectionPoints.Count > 0)
            {
                ConsoleUI.PrintTable(collectionPoints,
                    ("Listing ID", cp => cp.ListingId.ToString()),
                    ("Citizen", cp => cp.CitizenName ?? ""),
                    ("Category", cp => cp.CategoryName ?? ""),
                    ("Weight (kg)", cp => cp.Weight.ToString("F2")),
                    ("Price (Rs)", cp => (cp.EstimatedPrice ?? 0).ToString("F2")),
                    ("Area", cp => cp.AreaName ?? ""),
                    ("Status", cp => cp.Status ?? "")
                );

                Console.WriteLine($"\nTotal Collection Points: {collectionPoints.Count}");
            }
            else
            {
                ConsoleUI.PrintWarning("No collection points found on your route");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void PerformCollection(IOperatorService service)
        {
            ConsoleUI.PrintHeader("Perform Collection");

            string listingIdStr = ConsoleUI.ReadInput("Enter Listing ID");
            if (!InputValidator.ValidatePositiveInt(listingIdStr, out int listingId))
            {
                ConsoleUI.PrintError("Invalid Listing ID");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            string weightStr = ConsoleUI.ReadInput("Enter Collected Weight (kg)");
            if (!InputValidator.ValidatePositiveDecimal(weightStr, out decimal collectedWeight))
            {
                ConsoleUI.PrintError("Invalid weight");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            // Get warehouses
            var govService = ServiceFactory.GetGovernmentService();
            var warehouses = govService.GetAllWarehouses();

            Console.WriteLine("\nAvailable Warehouses:");
            foreach (var wh in warehouses)
            {
                Console.WriteLine($"{wh.WarehouseId}. {wh.WarehouseName}");
            }

            Console.WriteLine();
            string warehouseIdStr = ConsoleUI.ReadInput("Enter Warehouse ID");
            if (!InputValidator.ValidatePositiveInt(warehouseIdStr, out int warehouseId))
            {
                ConsoleUI.PrintError("Invalid Warehouse ID");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            bool result = service.PerformCollection(currentUserId, listingId, collectedWeight, warehouseId, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ViewOperatorPerformance(IOperatorService service)
        {
            ConsoleUI.PrintHeader("My Performance");

            var performance = service.GetMyPerformance(currentUserId);

            if (performance != null)
            {
                Console.WriteLine($"Total Pickups: {performance.TotalPickups ?? 0}");
                Console.WriteLine($"Total Weight Collected: {(performance.TotalCollectedWeight ?? 0):F2} kg");
                Console.WriteLine($"Total Amount Collected: Rs.{(performance.TotalCollectedAmount ?? 0):F2}");
            }
            else
            {
                ConsoleUI.PrintWarning("Performance data not available");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void UpdateOperatorStatus(IOperatorService service)
        {
            ConsoleUI.PrintHeader("Update Status");

            Console.WriteLine("Available Statuses:");
            Console.WriteLine("1. Available");
            Console.WriteLine("2. Busy");
            Console.WriteLine("3. Offline");

            int choice = int.Parse(ConsoleUI.ReadInput("\nSelect status") ?? "0");

            string status = choice switch
            {
                1 => "Available",
                2 => "Busy",
                3 => "Offline",
                _ => ""
            };

            if (string.IsNullOrEmpty(status))
            {
                ConsoleUI.PrintError("Invalid status");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            bool result = service.UpdateStatus(currentUserId, status, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void GovernmentDashboard()
        {
            bool running = true;
            var govService = ServiceFactory.GetGovernmentService();

            while (running)
            {
                ConsoleUI.PrintHeader("Government Regulator Dashboard");
                Console.WriteLine($"Implementation: {ServiceFactory.GetCurrentImplementationName()}");
                Console.WriteLine();

                var options = new[]
                {
                    "View Warehouse Inventory",
                    "View Stock by Category",
                    "Analyze High Yield Areas",
                    "View Operator Performance",
                    "View Partition Statistics",
                    "Manage Categories",
                    "Manage Operators",
                    "View Complaints",
                    "Logout"
                };

                int choice = ConsoleUI.ShowMenu("Government Menu", options);

                try
                {
                    switch (choice)
                    {
                        case 1:
                            ViewWarehouseInventory(govService);
                            break;
                        case 2:
                            ViewStockByCategory(govService);
                            break;
                        case 3:
                            AnalyzeHighYieldAreas(govService);
                            break;
                        case 4:
                            ViewAllOperatorPerformance(govService);
                            break;
                        case 5:
                            ViewPartitionStatistics(govService);
                            break;
                        case 6:
                            ManageCategories(govService);
                            break;
                        case 7:
                            ManageOperators(govService);
                            break;
                        case 8:
                            ViewComplaints(govService);
                            break;
                        case 9:
                            running = false;
                            break;
                        default:
                            ConsoleUI.PrintError("Invalid choice");
                            ConsoleUI.PressAnyKeyToContinue();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    ConsoleUI.PrintError($"Error: {ex.Message}");
                    ConsoleUI.PressAnyKeyToContinue();
                }
            }
        }

        static void ViewWarehouseInventory(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Warehouse Inventory");

            var inventory = service.GetWarehouseInventory();

            if (inventory.Count > 0)
            {
                ConsoleUI.PrintTable(inventory,
                    ("ID", i => i.WarehouseId.ToString()),
                    ("Name", i => i.WarehouseName ?? ""),
                    ("Area", i => i.AreaName ?? ""),
                    ("Capacity", i => i.Capacity.ToString("F2")),
                    ("Current", i => (i.CurrentInventory ?? 0).ToString("F2")),
                    ("Used %", i => (i.CapacityUsedPercent ?? 0).ToString("F1")),
                    ("Categories", i => (i.CategoryCount ?? 0).ToString())
                );
            }
            else
            {
                ConsoleUI.PrintWarning("No warehouse inventory data available");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ViewStockByCategory(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Stock by Category");

            var stock = service.GetStockByCategory();

            if (stock.Count > 0)
            {
                ConsoleUI.PrintTable(stock,
                    ("Warehouse ID", s => s.WarehouseId.ToString()),
                    ("Category", s => s.CategoryName ?? ""),
                    ("Weight (kg)", s => s.CurrentWeight.ToString("F2")),
                    ("Last Updated", s => (s.StockDate.HasValue ? s.StockDate.Value.ToString("yyyy-MM-dd") : ""))
                );
            }
            else
            {
                ConsoleUI.PrintWarning("No stock data available");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void AnalyzeHighYieldAreas(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("High Yield Areas Analysis");

            var areas = service.GetHighYieldAreas();

            if (areas.Count > 0)
            {
                Console.WriteLine("Top Areas by Revenue:");
                ConsoleUI.PrintSeparator();

                foreach (dynamic area in areas.Take(10))
                {
                    Console.WriteLine($"{area.AreaName}, {area.City}");
                    Console.WriteLine($"  Listings: {area.TotalListings}");
                    Console.WriteLine($"  Total Weight: {area.TotalWeight:F2} kg");
                    Console.WriteLine($"  Total Revenue: Rs.{area.TotalRevenue:F2}");
                    Console.WriteLine();
                }
            }
            else
            {
                ConsoleUI.PrintWarning("No data available");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ViewAllOperatorPerformance(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Operator Performance");

            var performance = service.GetOperatorPerformance();

            if (performance.Count > 0)
            {
                ConsoleUI.PrintTable(performance,
                    ("Operator ID", p => p.OperatorId ?? ""),
                    ("Name", p => p.FullName ?? ""),
                    ("Pickups", p => (p.TotalPickups ?? 0).ToString()),
                    ("Weight (kg)", p => (p.TotalCollectedWeight ?? 0).ToString("F2")),
                    ("Amount (Rs)", p => (p.TotalCollectedAmount ?? 0).ToString("F2"))
                );
            }
            else
            {
                ConsoleUI.PrintWarning("No performance data available");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ViewPartitionStatistics(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Partition Statistics");

            var stats = service.GetPartitionStatistics();

            if (stats.Count > 0)
            {
                ConsoleUI.PrintTable(stats,
                    ("Table", s => s.TableName ?? ""),
                    ("Partition", s => s.PartitionNumber.ToString()),
                    ("Boundary", s => s.RangeBoundary ?? ""),
                    ("Records", s => (s.RecordCount ?? 0).ToString()),
                    ("Size (MB)", s => (s.SizeMb ?? 0).ToString("F2"))
                );
            }
            else
            {
                ConsoleUI.PrintWarning("No partition statistics available");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ManageCategories(IGovernmentService service)
        {
            bool running = true;

            while (running)
            {
                ConsoleUI.PrintHeader("Manage Categories");

                var options = new[]
                {
                    "View All Categories",
                    "Create Category",
                    "Update Category Price",
                    "Delete Category",
                    "Back"
                };

                int choice = ConsoleUI.ShowMenu("Category Management", options);

                try
                {
                    switch (choice)
                    {
                        case 1:
                            ViewCategories(service);
                            break;
                        case 2:
                            CreateCategory(service);
                            break;
                        case 3:
                            UpdateCategoryPrice(service);
                            break;
                        case 4:
                            DeleteCategory(service);
                            break;
                        case 5:
                            running = false;
                            break;
                        default:
                            ConsoleUI.PrintError("Invalid choice");
                            ConsoleUI.PressAnyKeyToContinue();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    ConsoleUI.PrintError($"Error: {ex.Message}");
                    ConsoleUI.PressAnyKeyToContinue();
                }
            }
        }

        static void ViewCategories(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("All Categories");

            var categories = service.GetAllCategories();

            if (categories.Count > 0)
            {
                ConsoleUI.PrintTable(categories,
                    ("ID", c => c.CategoryId.ToString()),
                    ("Name", c => c.CategoryName ?? ""),
                    ("Price/kg (Rs)", c => c.BasePricePerKg.ToString("F2")),
                    ("Description", c => c.Description ?? "")
                );
            }
            else
            {
                ConsoleUI.PrintWarning("No categories found");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void CreateCategory(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Create Category");

            string categoryName = ConsoleUI.ReadInput("Enter Category Name");
            string priceStr = ConsoleUI.ReadInput("Enter Base Price Per Kg");

            if (!InputValidator.ValidatePositiveDecimal(priceStr, out decimal basePricePerKg))
            {
                ConsoleUI.PrintError("Invalid price");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            string description = ConsoleUI.ReadInput("Enter Description");

            bool result = service.CreateCategory(categoryName, basePricePerKg, description, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void UpdateCategoryPrice(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Update Category Price");

            ViewCategories(service);

            string categoryIdStr = ConsoleUI.ReadInput("Enter Category ID");
            if (!InputValidator.ValidatePositiveInt(categoryIdStr, out int categoryId))
            {
                ConsoleUI.PrintError("Invalid Category ID");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            string priceStr = ConsoleUI.ReadInput("Enter New Price Per Kg");
            if (!InputValidator.ValidatePositiveDecimal(priceStr, out decimal newPrice))
            {
                ConsoleUI.PrintError("Invalid price");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            bool result = service.UpdateCategoryPrice(categoryId, newPrice, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void DeleteCategory(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Delete Category");

            ViewCategories(service);

            string categoryIdStr = ConsoleUI.ReadInput("Enter Category ID to delete");
            if (!InputValidator.ValidatePositiveInt(categoryIdStr, out int categoryId))
            {
                ConsoleUI.PrintError("Invalid Category ID");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            string confirm = ConsoleUI.ReadInput("Are you sure? (yes/no)");
            if (confirm.ToLower() != "yes")
            {
                ConsoleUI.PrintInfo("Operation cancelled");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            bool result = service.DeleteCategory(categoryId, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ManageOperators(IGovernmentService service)
        {
            bool running = true;

            while (running)
            {
                ConsoleUI.PrintHeader("Manage Operators");

                var options = new[]
                {
                    "View All Operators",
                    "Create Operator",
                    "Assign Operator to Route",
                    "Deactivate Operator",
                    "Back"
                };

                int choice = ConsoleUI.ShowMenu("Operator Management", options);

                try
                {
                    switch (choice)
                    {
                        case 1:
                            ViewAllOperators(service);
                            break;
                        case 2:
                            CreateOperator(service);
                            break;
                        case 3:
                            AssignOperatorToRoute(service);
                            break;
                        case 4:
                            DeactivateOperator(service);
                            break;
                        case 5:
                            running = false;
                            break;
                        default:
                            ConsoleUI.PrintError("Invalid choice");
                            ConsoleUI.PressAnyKeyToContinue();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    ConsoleUI.PrintError($"Error: {ex.Message}");
                    ConsoleUI.PressAnyKeyToContinue();
                }
            }
        }

        static void ViewAllOperators(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("All Operators");

            var operators = service.GetAllOperators();

            if (operators.Count > 0)
            {
                ConsoleUI.PrintTable(operators,
                    ("CNIC", o => o.OperatorId ?? ""),
                    ("Name", o => o.FullName ?? ""),
                    ("Status", o => o.Status ?? ""),
                    ("Route", o => o.Route?.RouteName ?? "Not Assigned"),
                    ("Warehouse", o => o.Warehouse?.WarehouseName ?? "Not Assigned")
                );
            }
            else
            {
                ConsoleUI.PrintWarning("No operators found");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void CreateOperator(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Create Operator");

            string cnic = ConsoleUI.ReadInput("Enter CNIC (format: XXXXX-XXXXXXX-X)");
            if (!InputValidator.ValidateCNIC(cnic))
            {
                ConsoleUI.PrintError("Invalid CNIC format");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            string fullName = ConsoleUI.ReadInput("Enter Full Name");
            string phoneNumber = ConsoleUI.ReadInput("Enter Phone Number");

            bool result = service.CreateOperator(cnic, fullName, phoneNumber, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void AssignOperatorToRoute(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Assign Operator to Route");

            ViewAllOperators(service);

            string operatorId = ConsoleUI.ReadInput("Enter Operator CNIC");

            // Show routes
            var routes = service.GetAllRoutes();
            Console.WriteLine("\nAvailable Routes:");
            foreach (var route in routes)
            {
                Console.WriteLine($"{route.RouteId}. {route.RouteName} ({route.Area?.AreaName})");
            }

            string routeIdStr = ConsoleUI.ReadInput("\nEnter Route ID");
            if (!InputValidator.ValidatePositiveInt(routeIdStr, out int routeId))
            {
                ConsoleUI.PrintError("Invalid Route ID");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            // Show warehouses
            var warehouses = service.GetAllWarehouses();
            Console.WriteLine("\nAvailable Warehouses:");
            foreach (var wh in warehouses)
            {
                Console.WriteLine($"{wh.WarehouseId}. {wh.WarehouseName}");
            }

            string warehouseIdStr = ConsoleUI.ReadInput("\nEnter Warehouse ID");
            if (!InputValidator.ValidatePositiveInt(warehouseIdStr, out int warehouseId))
            {
                ConsoleUI.PrintError("Invalid Warehouse ID");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            bool result = service.AssignOperatorToRoute(operatorId, routeId, warehouseId, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void DeactivateOperator(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Deactivate Operator");

            ViewAllOperators(service);

            string operatorId = ConsoleUI.ReadInput("Enter Operator CNIC to deactivate");

            string confirm = ConsoleUI.ReadInput("Are you sure? (yes/no)");
            if (confirm.ToLower() != "yes")
            {
                ConsoleUI.PrintInfo("Operation cancelled");
                ConsoleUI.PressAnyKeyToContinue();
                return;
            }

            bool result = service.DeactivateOperator(operatorId, out string message);

            if (result)
            {
                ConsoleUI.PrintSuccess(message);
            }
            else
            {
                ConsoleUI.PrintError(message);
            }

            ConsoleUI.PressAnyKeyToContinue();
        }

        static void ViewComplaints(IGovernmentService service)
        {
            ConsoleUI.PrintHeader("Complaints");

            var activeComplaints = service.GetActiveComplaints();

            if (activeComplaints.Count > 0)
            {
                Console.WriteLine("Active Complaints:");
                ConsoleUI.PrintTable(activeComplaints,
                    ("ID", c => c.ComplaintId.ToString()),
                    ("Type", c => c.ComplaintType ?? ""),
                    ("Citizen", c => c.CitizenName ?? ""),
                    ("Operator", c => c.OperatorName ?? "N/A"),
                    ("Status", c => c.Status ?? ""),
                    ("Days Open", c => (c.DaysOpen ?? 0).ToString())
                );
            }
            else
            {
                ConsoleUI.PrintWarning("No active complaints");
            }

            ConsoleUI.PressAnyKeyToContinue();
        }
    }
}
