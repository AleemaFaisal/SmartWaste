using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.Interfaces
{
    public interface IOperatorService
    {
        // View collection points on assigned route
        List<VwOperatorCollectionPoint> GetCollectionPoints(string operatorId);

        // Perform collection operation
        bool PerformCollection(string operatorId, int listingId, decimal collectedWeight, int warehouseId, out string message);

        // View my performance
        VwOperatorPerformance GetMyPerformance(string operatorId);

        // View my route details
        Route GetMyRoute(string operatorId);

        // Get operator profile
        Operator GetProfile(string operatorId);

        // Update operator status
        bool UpdateStatus(string operatorId, string status, out string message);
    }
}
