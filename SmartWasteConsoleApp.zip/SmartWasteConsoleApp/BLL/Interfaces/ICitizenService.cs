using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.Interfaces
{
    public interface ICitizenService
    {
        // Register a new citizen
        bool RegisterCitizen(string userId, string password, string fullName, string phoneNumber, int areaId, string address, out string message);

        // Create a waste listing and get price estimation
        bool CreateWasteListing(string citizenId, int categoryId, decimal weight, out int listingId, out decimal estimatedPrice, out string message);

        // Get price estimation without creating listing
        decimal GetPriceEstimation(int categoryId, decimal weight);

        // Publish listing (create transaction record)
        bool PublishListing(string citizenId, List<int> listingIds, out string message);

        // View my listings
        List<WasteListing> GetMyListings(string citizenId);

        // View my transactions
        List<VwTransactionSummary> GetMyTransactions(string citizenId);

        // View profile
        VwCitizenProfile GetProfile(string citizenId);
    }
}
