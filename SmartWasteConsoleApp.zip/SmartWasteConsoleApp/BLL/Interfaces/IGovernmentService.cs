using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.Interfaces
{
    public interface IGovernmentService
    {
        // Warehouse Analytics
        List<VwWarehouseInventory> GetWarehouseInventory();
        VwWarehouseInventory GetWarehouseById(int warehouseId);
        List<VwLatestStockByCategory> GetStockByCategory();

        // Reports and Analytics
        List<dynamic> GetHighYieldAreas();
        List<VwOperatorPerformance> GetOperatorPerformance();
        List<VwPartitionStatistic> GetPartitionStatistics();

        // Manage Pricing and Categories
        List<Category> GetAllCategories();
        bool CreateCategory(string categoryName, decimal basePricePerKg, string description, out string message);
        bool UpdateCategoryPrice(int categoryId, decimal newPrice, out string message);
        bool DeleteCategory(int categoryId, out string message);

        // Manage Operators
        bool CreateOperator(string cnic, string fullName, string phoneNumber, out string message);
        bool AssignOperatorToRoute(string operatorId, int routeId, int warehouseId, out string message);
        bool DeactivateOperator(string operatorId, out string message);
        List<Operator> GetAllOperators();

        // Review Complaints
        List<VwActiveComplaint> GetActiveComplaints();
        List<Complaint> GetAllComplaints();
        bool UpdateComplaintStatus(int complaintId, string status, out string message);

        // Get Areas and Routes
        List<Area> GetAllAreas();
        List<Route> GetAllRoutes();
        List<Warehouse> GetAllWarehouses();
    }
}
