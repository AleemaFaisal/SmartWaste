using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.Interfaces
{
    public interface IAuthService
    {
        // Authenticate user and return user info with role
        (bool success, User user, string roleName, string message) AuthenticateUser(string userId, string password);

        // Verify password
        bool VerifyPassword(string password, string storedHash);

        // Hash password
        string HashPassword(string password);
    }
}
