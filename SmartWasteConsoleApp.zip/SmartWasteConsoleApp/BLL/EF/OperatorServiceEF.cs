using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Data;
using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.EF
{
    public class OperatorServiceEF : IOperatorService
    {
        private readonly SmartWasteDbContext _context;

        public OperatorServiceEF()
        {
            _context = new SmartWasteDbContext();
        }

        public List<VwOperatorCollectionPoint> GetCollectionPoints(string operatorId)
        {
            var operator_ = _context.Operators
                .Include(o => o.Route)
                .FirstOrDefault(o => o.OperatorId == operatorId);

            if (operator_ == null || operator_.RouteId == null)
                return new List<VwOperatorCollectionPoint>();

            return _context.VwOperatorCollectionPoints
                .Where(vcp => vcp.OperatorId == operatorId)
                .ToList();
        }

        public bool PerformCollection(string operatorId, int listingId, decimal collectedWeight, int warehouseId, out string message)
        {
            try
            {
                // Validate operator
                var operator_ = _context.Operators.Find(operatorId);
                if (operator_ == null)
                {
                    message = "Operator not found";
                    return false;
                }

                // Validate listing
                var listing = _context.WasteListings.Find(listingId, DateTime.Now);
                if (listing == null)
                {
                    // Try to find listing without datetime
                    listing = _context.WasteListings
                        .FirstOrDefault(wl => wl.ListingId == listingId);
                }

                if (listing == null)
                {
                    message = "Listing not found";
                    return false;
                }

                if (listing.Status != "Pending")
                {
                    message = "Listing is not in pending status";
                    return false;
                }

                // Validate warehouse
                var warehouse = _context.Warehouses.Find(warehouseId);
                if (warehouse == null)
                {
                    message = "Warehouse not found";
                    return false;
                }

                // Check warehouse capacity
                if ((warehouse.CurrentInventory ?? 0) + (double)collectedWeight > warehouse.Capacity)
                {
                    message = "Warehouse capacity exceeded";
                    return false;
                }

                using var transaction = _context.Database.BeginTransaction();

                try
                {
                    // Create collection record
                    var collection = new Collection
                    {
                        OperatorId = operatorId,
                        ListingId = listingId,
                        CollectedDate = DateTime.Now,
                        CollectedWeight = collectedWeight,
                        IsVerified = true,
                        WarehouseId = warehouseId,
                        PhotoProof = null
                    };

                    _context.Collections.Add(collection);

                    // Update listing status (trigger will handle this)
                    listing.Status = "Collected";

                    // Update warehouse stock
                    var stock = _context.WarehouseStocks
                        .FirstOrDefault(ws => ws.WarehouseId == warehouseId && ws.CategoryId == listing.CategoryId);

                    if (stock == null)
                    {
                        stock = new WarehouseStock
                        {
                            WarehouseId = warehouseId,
                            CategoryId = listing.CategoryId,
                            CurrentWeight = (double)collectedWeight,
                            LastUpdated = DateTime.Now
                        };
                        _context.WarehouseStocks.Add(stock);
                    }
                    else
                    {
                        stock.CurrentWeight += (double)collectedWeight;
                        stock.LastUpdated = DateTime.Now;
                    }

                    // Update transaction status to completed
                    if (listing.TransactionId.HasValue)
                    {
                        var transactionRecord = _context.TransactionRecords
                            .FirstOrDefault(tr => tr.TransactionId == listing.TransactionId.Value);
                        if (transactionRecord != null)
                        {
                            transactionRecord.PaymentStatus = "Completed";
                            transactionRecord.OperatorId = operatorId;
                        }
                    }

                    _context.SaveChanges();
                    transaction.Commit();

                    message = "Collection performed successfully";
                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    message = $"Error performing collection: {ex.Message}";
                    return false;
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public VwOperatorPerformance GetMyPerformance(string operatorId)
        {
            return _context.VwOperatorPerformances
                .FirstOrDefault(vop => vop.OperatorId == operatorId);
        }

        public Route GetMyRoute(string operatorId)
        {
            var operator_ = _context.Operators
                .Include(o => o.Route)
                    .ThenInclude(r => r.Area)
                .FirstOrDefault(o => o.OperatorId == operatorId);

            return operator_?.Route;
        }

        public Operator GetProfile(string operatorId)
        {
            return _context.Operators
                .Include(o => o.Route)
                .Include(o => o.Warehouse)
                .FirstOrDefault(o => o.OperatorId == operatorId);
        }

        public bool UpdateStatus(string operatorId, string status, out string message)
        {
            try
            {
                var operator_ = _context.Operators.Find(operatorId);
                if (operator_ == null)
                {
                    message = "Operator not found";
                    return false;
                }

                if (!new[] { "Available", "Busy", "Offline" }.Contains(status))
                {
                    message = "Invalid status. Must be: Available, Busy, or Offline";
                    return false;
                }

                operator_.Status = status;
                _context.SaveChanges();

                message = $"Status updated to {status}";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Error updating status: {ex.Message}";
                return false;
            }
        }
    }
}
