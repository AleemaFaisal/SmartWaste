using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Data;
using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.EF
{
    public class GovernmentServiceEF : IGovernmentService
    {
        private readonly SmartWasteDbContext _context;

        public GovernmentServiceEF()
        {
            _context = new SmartWasteDbContext();
        }

        // Warehouse Analytics
        public List<VwWarehouseInventory> GetWarehouseInventory()
        {
            return _context.VwWarehouseInventories.ToList();
        }

        public VwWarehouseInventory GetWarehouseById(int warehouseId)
        {
            return _context.VwWarehouseInventories
                .FirstOrDefault(vwi => vwi.WarehouseId == warehouseId);
        }

        public List<VwLatestStockByCategory> GetStockByCategory()
        {
            return _context.VwLatestStockByCategories.ToList();
        }

        // Reports and Analytics using CTEs (through views and LINQ)
        public List<dynamic> GetHighYieldAreas()
        {
            // Using LINQ to replicate the CTE logic
            var areaRevenue = from area in _context.Areas
                              join citizen in _context.Citizens on area.AreaId equals citizen.AreaId into citizenGroup
                              from citizen in citizenGroup.DefaultIfEmpty()
                              join listing in _context.WasteListings on citizen.CitizenId equals listing.CitizenId into listingGroup
                              from listing in listingGroup.DefaultIfEmpty()
                              where listing == null || (listing.Status == "Collected" || listing.Status == "Completed")
                              group new { area, listing } by new { area.AreaId, area.AreaName, area.City } into g
                              select new
                              {
                                  AreaId = g.Key.AreaId,
                                  AreaName = g.Key.AreaName,
                                  City = g.Key.City,
                                  TotalListings = g.Count(x => x.listing != null),
                                  TotalWeight = g.Sum(x => x.listing != null ? x.listing.Weight : 0),
                                  TotalRevenue = g.Sum(x => x.listing != null ? (x.listing.EstimatedPrice ?? 0) : 0)
                              };

            var result = areaRevenue
                .OrderByDescending(ar => ar.TotalRevenue)
                .ToList<dynamic>();

            return result;
        }

        public List<VwOperatorPerformance> GetOperatorPerformance()
        {
            return _context.VwOperatorPerformances
                .OrderByDescending(vop => vop.TotalPickups)
                .ToList();
        }

        public List<VwPartitionStatistic> GetPartitionStatistics()
        {
            return _context.VwPartitionStatistics
                .OrderBy(vps => vps.TableName)
                .ThenBy(vps => vps.PartitionNumber)
                .ToList();
        }

        // Manage Pricing and Categories
        public List<Category> GetAllCategories()
        {
            return _context.Categories.ToList();
        }

        public bool CreateCategory(string categoryName, decimal basePricePerKg, string description, out string message)
        {
            try
            {
                if (basePricePerKg < 0)
                {
                    message = "Price cannot be negative";
                    return false;
                }

                if (_context.Categories.Any(c => c.CategoryName == categoryName))
                {
                    message = "Category with this name already exists";
                    return false;
                }

                var category = new Category
                {
                    CategoryName = categoryName,
                    BasePricePerKg = basePricePerKg,
                    Description = description
                };

                _context.Categories.Add(category);
                _context.SaveChanges();

                message = "Category created successfully";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Error creating category: {ex.Message}";
                return false;
            }
        }

        public bool UpdateCategoryPrice(int categoryId, decimal newPrice, out string message)
        {
            try
            {
                if (newPrice < 0)
                {
                    message = "Price cannot be negative";
                    return false;
                }

                var category = _context.Categories.Find(categoryId);
                if (category == null)
                {
                    message = "Category not found";
                    return false;
                }

                category.BasePricePerKg = newPrice;
                _context.SaveChanges();
                // Trigger will automatically update pending listing prices

                message = "Category price updated successfully";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Error updating category price: {ex.Message}";
                return false;
            }
        }

        public bool DeleteCategory(int categoryId, out string message)
        {
            try
            {
                var category = _context.Categories.Find(categoryId);
                if (category == null)
                {
                    message = "Category not found";
                    return false;
                }

                // Check if category is in use
                if (_context.WasteListings.Any(wl => wl.CategoryId == categoryId))
                {
                    message = "Cannot delete category that has associated waste listings";
                    return false;
                }

                _context.Categories.Remove(category);
                _context.SaveChanges();

                message = "Category deleted successfully";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Error deleting category: {ex.Message}";
                return false;
            }
        }

        // Manage Operators
        public bool CreateOperator(string cnic, string fullName, string phoneNumber, out string message)
        {
            try
            {
                // Validate CNIC format
                if (!ValidateCNIC(cnic))
                {
                    message = "Invalid CNIC format. Expected format: XXXXX-XXXXXXX-X";
                    return false;
                }

                // Check if user already exists
                if (_context.Users.Any(u => u.UserId == cnic))
                {
                    message = "User with this CNIC already exists";
                    return false;
                }

                using var transaction = _context.Database.BeginTransaction();

                try
                {
                    // Generate password
                    string password = GeneratePassword();

                    // Create user
                    var user = new User
                    {
                        UserId = cnic,
                        PasswordHash = HashPassword(password),
                        RoleId = 3, // Operator role
                        CreatedAt = DateTime.Now
                    };
                    _context.Users.Add(user);
                    _context.SaveChanges();

                    // Create operator
                    var operator_ = new Operator
                    {
                        OperatorId = cnic,
                        FullName = fullName,
                        PhoneNumber = phoneNumber,
                        Status = "Available"
                    };
                    _context.Operators.Add(operator_);
                    _context.SaveChanges();

                    transaction.Commit();
                    message = $"Operator created successfully. Password: {password}";
                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    message = $"Error creating operator: {ex.Message}";
                    return false;
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public bool AssignOperatorToRoute(string operatorId, int routeId, int warehouseId, out string message)
        {
            try
            {
                // Check if route already has an operator
                if (_context.Operators.Any(o => o.RouteId == routeId && o.OperatorId != operatorId))
                {
                    message = "Route already has an assigned operator";
                    return false;
                }

                var operator_ = _context.Operators.Find(operatorId);
                if (operator_ == null)
                {
                    message = "Operator not found";
                    return false;
                }

                if (!_context.Routes.Any(r => r.RouteId == routeId))
                {
                    message = "Route not found";
                    return false;
                }

                if (!_context.Warehouses.Any(w => w.WarehouseId == warehouseId))
                {
                    message = "Warehouse not found";
                    return false;
                }

                operator_.RouteId = routeId;
                operator_.WarehouseId = warehouseId;
                _context.SaveChanges();

                message = "Operator assigned to route successfully";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Error assigning operator to route: {ex.Message}";
                return false;
            }
        }

        public bool DeactivateOperator(string operatorId, out string message)
        {
            try
            {
                var operator_ = _context.Operators.Find(operatorId);
                if (operator_ == null)
                {
                    message = "Operator not found";
                    return false;
                }

                operator_.Status = "Offline";
                operator_.RouteId = null;
                operator_.WarehouseId = null;
                _context.SaveChanges();

                message = "Operator deactivated successfully";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Error deactivating operator: {ex.Message}";
                return false;
            }
        }

        public List<Operator> GetAllOperators()
        {
            return _context.Operators
                .Include(o => o.Route)
                .Include(o => o.Warehouse)
                .ToList();
        }

        // Review Complaints
        public List<VwActiveComplaint> GetActiveComplaints()
        {
            return _context.VwActiveComplaints.ToList();
        }

        public List<Complaint> GetAllComplaints()
        {
            return _context.Complaints
                .Include(c => c.Citizen)
                .Include(c => c.Operator)
                .OrderByDescending(c => c.CreatedAt)
                .ToList();
        }

        public bool UpdateComplaintStatus(int complaintId, string status, out string message)
        {
            try
            {
                var complaint = _context.Complaints.Find(complaintId);
                if (complaint == null)
                {
                    message = "Complaint not found";
                    return false;
                }

                if (!new[] { "Open", "In Progress", "Resolved", "Closed" }.Contains(status))
                {
                    message = "Invalid status. Must be: Open, In Progress, Resolved, or Closed";
                    return false;
                }

                complaint.Status = status;
                _context.SaveChanges();

                message = $"Complaint status updated to {status}";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Error updating complaint status: {ex.Message}";
                return false;
            }
        }

        // Helper methods
        public List<Area> GetAllAreas()
        {
            return _context.Areas.ToList();
        }

        public List<Route> GetAllRoutes()
        {
            return _context.Routes
                .Include(r => r.Area)
                .ToList();
        }

        public List<Warehouse> GetAllWarehouses()
        {
            return _context.Warehouses
                .Include(w => w.Area)
                .ToList();
        }

        private bool ValidateCNIC(string cnic)
        {
            if (string.IsNullOrEmpty(cnic)) return false;
            var parts = cnic.Split('-');
            return parts.Length == 3 &&
                   parts[0].Length == 5 && parts[0].All(char.IsDigit) &&
                   parts[1].Length == 7 && parts[1].All(char.IsDigit) &&
                   parts[2].Length == 1 && parts[2].All(char.IsDigit);
        }

        private string GeneratePassword()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, 12)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private string HashPassword(string password)
        {
            using (System.Security.Cryptography.SHA256 sha256 = System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }
}
