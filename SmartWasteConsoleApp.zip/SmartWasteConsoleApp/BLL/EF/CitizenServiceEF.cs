using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Data;
using SmartWasteConsoleApp.Models;
using System.Security.Cryptography;
using System.Text;

namespace SmartWasteConsoleApp.BLL.EF
{
    public class CitizenServiceEF : ICitizenService
    {
        private readonly SmartWasteDbContext _context;

        public CitizenServiceEF()
        {
            _context = new SmartWasteDbContext();
        }

        public bool RegisterCitizen(string userId, string password, string fullName,
                            string phoneNumber, int areaId, string address,
                            out string message)
{
    try
    {
        // Validate CNIC format
        if (!ValidateCNIC(userId))
        {
            message = "Invalid CNIC format. Expected format: XXXXX-XXXXXXX-X";
            return false;
        }

        // Check if user already exists
        if (_context.Users.Any(u => u.UserId == userId))
        {
            message = "User with this CNIC already exists";
            return false;
        }

        // Check if area exists
        if (!_context.Areas.Any(a => a.AreaId == areaId))
        {
            message = "Invalid area ID";
            return false;
        }

        // Use EF Core's execution strategy
        var strategy = _context.Database.CreateExecutionStrategy();

        bool result = false;
        string innerMessage = "";

        strategy.Execute(() =>
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                // Create user
                var user = new User
                {
                    UserId = userId,
                    PasswordHash = HashPassword(password),
                    RoleId = 2,
                    CreatedAt = DateTime.Now
                };
                _context.Users.Add(user);
                _context.SaveChanges();

                // Create citizen
                var citizen = new Citizen
                {
                    CitizenId = userId,
                    FullName = fullName,
                    PhoneNumber = phoneNumber,
                    AreaId = areaId,
                    Address = address
                };
                _context.Citizens.Add(citizen);
                _context.SaveChanges();

                transaction.Commit();

                innerMessage = "Citizen registered successfully";
                result = true;
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                innerMessage = $"Error registering citizen: {ex.Message}";
                result = false;
            }
        });

        message = innerMessage;
        return result;
    }
    catch (Exception ex)
    {
        message = $"Error: {ex.Message}";
        return false;
    }
}


        public bool CreateWasteListing(string citizenId, int categoryId, decimal weight, out int listingId, out decimal estimatedPrice, out string message)
        {
            listingId = 0;
            estimatedPrice = 0;

            try
            {
                // Validate citizen exists
                if (!_context.Citizens.Any(c => c.CitizenId == citizenId))
                {
                    message = "Citizen not found";
                    return false;
                }

                // Calculate price
                estimatedPrice = GetPriceEstimation(categoryId, weight);

                // Create listing
                var listing = new WasteListing
                {
                    CitizenId = citizenId,
                    CategoryId = categoryId,
                    Weight = weight,
                    EstimatedPrice = estimatedPrice,
                    Status = "Pending",
                    CreatedAt = DateTime.Now
                };

                _context.WasteListings.Add(listing);
                _context.SaveChanges();

                listingId = listing.ListingId;
                message = "Waste listing created successfully";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Error creating waste listing: {ex.Message}";
                return false;
            }
        }

        public decimal GetPriceEstimation(int categoryId, decimal weight)
        {
            var category = _context.Categories.Find(categoryId);
            if (category == null) return 0;
            return category.BasePricePerKg * weight;
        }

        public bool PublishListing(string citizenId, List<int> listingIds, out string message)
        {
            try
            {
                // Validate citizen exists
                if (!_context.Citizens.Any(c => c.CitizenId == citizenId))
                {
                    message = "Citizen not found";
                    return false;
                }

                // Get listings
                var listings = _context.WasteListings
                    .Where(wl => listingIds.Contains(wl.ListingId) && wl.CitizenId == citizenId && wl.Status == "Pending")
                    .ToList();

                if (listings.Count == 0)
                {
                    message = "No valid pending listings found";
                    return false;
                }

                using var transaction = _context.Database.BeginTransaction();

                try
                {
                    // Calculate total amount
                    decimal totalAmount = listings.Sum(l => l.EstimatedPrice ?? 0);

                    // Create transaction record
                    var transactionRecord = new TransactionRecord
                    {
                        CitizenId = citizenId,
                        TotalAmount = totalAmount,
                        PaymentStatus = "Pending",
                        PaymentMethod = "Digital Wallet",
                        TransactionDate = DateTime.Now,
                        VerificationCode = "VER-" + Guid.NewGuid().ToString()
                    };

                    _context.TransactionRecords.Add(transactionRecord);
                    _context.SaveChanges();

                    // Update listings with transaction ID
                    foreach (var listing in listings)
                    {
                        listing.TransactionId = transactionRecord.TransactionId;
                    }
                    _context.SaveChanges();

                    transaction.Commit();
                    message = $"Published {listings.Count} listings successfully. Verification Code: {transactionRecord.VerificationCode}";
                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    message = $"Error publishing listings: {ex.Message}";
                    return false;
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public List<WasteListing> GetMyListings(string citizenId)
        {
            return _context.WasteListings
                .Include(wl => wl.Category)
                .Where(wl => wl.CitizenId == citizenId)
                .OrderByDescending(wl => wl.CreatedAt)
                .ToList();
        }

        public List<VwTransactionSummary> GetMyTransactions(string citizenId)
        {
            return _context.VwTransactionSummaries
                .Where(vt => vt.CitizenName != null) // Filter for citizen
                .ToList();
        }

        public VwCitizenProfile GetProfile(string citizenId)
        {
            return _context.VwCitizenProfiles
                .FirstOrDefault(vcp => vcp.CitizenId == citizenId);
        }

        private bool ValidateCNIC(string cnic)
        {
            if (string.IsNullOrEmpty(cnic)) return false;
            var parts = cnic.Split('-');
            return parts.Length == 3 &&
                   parts[0].Length == 5 && parts[0].All(char.IsDigit) &&
                   parts[1].Length == 7 && parts[1].All(char.IsDigit) &&
                   parts[2].Length == 1 && parts[2].All(char.IsDigit);
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }
}
