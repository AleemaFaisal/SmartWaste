using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Data;
using SmartWasteConsoleApp.Models;
using System.Security.Cryptography;
using System.Text;

namespace SmartWasteConsoleApp.BLL.EF
{
    public class AuthServiceEF : IAuthService
    {
        private readonly SmartWasteDbContext _context;

        public AuthServiceEF()
        {
            _context = new SmartWasteDbContext();
        }

        public (bool success, User user, string roleName, string message) AuthenticateUser(string userId, string password)
        {
            try
            {
                // Find user
                var user = _context.Users
                    .Include(u => u.Role)
                    .FirstOrDefault(u => u.UserId == userId);

                if (user == null)
                {
                    return (false, null!, "", "User not found. Please check your CNIC.");
                }

                // Verify password
                if (!VerifyPassword(password, user.PasswordHash))
                {
                    return (false, null!, "", "Invalid password. Please try again.");
                }

                // Get role name
                string roleName = user.Role?.RoleName ?? "Unknown";

                return (true, user, roleName, "Authentication successful");
            }
            catch (Exception ex)
            {
                return (false, null!, "", $"Error during authentication: {ex.Message}");
            }
        }

        public bool VerifyPassword(string password, string storedHash)
        {
            // Hash the input password
            string hashedInput = HashPassword(password);

            // Compare with stored hash
            return hashedInput == storedHash;
        }

        public string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }
}
