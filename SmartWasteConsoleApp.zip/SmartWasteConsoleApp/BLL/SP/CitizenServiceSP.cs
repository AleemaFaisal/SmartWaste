using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Data;
using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.SP
{
    public class CitizenServiceSP : ICitizenService
    {
        private readonly SmartWasteDbContext _context;
        private readonly string _connectionString;

        public CitizenServiceSP()
        {
            _context = new SmartWasteDbContext();
            _connectionString = "Server=localhost;Database=SmartWasteDB;User Id=sa;Password=mak@1234;TrustServerCertificate=True;Connection Timeout=60;Pooling=true;Max Pool Size=100;MultipleActiveResultSets=True;";
        }

        public bool RegisterCitizen(string userId, string password, string fullName, string phoneNumber, int areaId, string address, out string message)
        {
            message = string.Empty;

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand("WasteManagement.sp_RegisterCitizen", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        // Hash password
                        string passwordHash = HashPassword(password);

                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@PasswordHash", passwordHash);
                        command.Parameters.AddWithValue("@FullName", fullName);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        command.Parameters.AddWithValue("@AreaID", areaId);
                        command.Parameters.AddWithValue("@Address", address);

                        var resultMessageParam = new SqlParameter("@ResultMessage", System.Data.SqlDbType.VarChar, 255)
                        {
                            Direction = System.Data.ParameterDirection.Output
                        };
                        command.Parameters.Add(resultMessageParam);

                        var returnValue = new SqlParameter()
                        {
                            Direction = System.Data.ParameterDirection.ReturnValue
                        };
                        command.Parameters.Add(returnValue);

                        command.ExecuteNonQuery();

                        message = resultMessageParam.Value?.ToString() ?? "";
                        int result = (int)returnValue.Value;

                        return result == 0;
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public bool CreateWasteListing(string citizenId, int categoryId, decimal weight, out int listingId, out decimal estimatedPrice, out string message)
        {
            listingId = 0;
            estimatedPrice = 0;
            message = string.Empty;

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand("WasteManagement.sp_CreateWasteListing", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@CitizenID", citizenId);
                        command.Parameters.AddWithValue("@CategoryID", categoryId);
                        command.Parameters.AddWithValue("@Weight", weight);

                        var listingIdParam = new SqlParameter("@ListingID", System.Data.SqlDbType.Int)
                        {
                            Direction = System.Data.ParameterDirection.Output
                        };
                        command.Parameters.Add(listingIdParam);

                        var estimatedPriceParam = new SqlParameter("@EstimatedPrice", System.Data.SqlDbType.Decimal)
                        {
                            Direction = System.Data.ParameterDirection.Output,
                            Precision = 10,
                            Scale = 2
                        };
                        command.Parameters.Add(estimatedPriceParam);

                        var returnValue = new SqlParameter()
                        {
                            Direction = System.Data.ParameterDirection.ReturnValue
                        };
                        command.Parameters.Add(returnValue);

                        command.ExecuteNonQuery();

                        listingId = (int)listingIdParam.Value;
                        estimatedPrice = (decimal)estimatedPriceParam.Value;
                        int result = (int)returnValue.Value;

                        message = result == 0 ? "Waste listing created successfully" : "Error creating waste listing";
                        return result == 0;
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public decimal GetPriceEstimation(int categoryId, decimal weight)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand("SELECT WasteManagement.fn_CalculatePrice(@CategoryID, @Weight)", connection))
                    {
                        command.Parameters.AddWithValue("@CategoryID", categoryId);
                        command.Parameters.AddWithValue("@Weight", weight);

                        var result = command.ExecuteScalar();
                        return result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                    }
                }
            }
            catch
            {
                return 0;
            }
        }

        public bool PublishListing(string citizenId, List<int> listingIds, out string message)
        {
            // This operation doesn't have a specific SP, so we use ADO.NET directly
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Get listings and calculate total
                            decimal totalAmount = 0;
                            var validListings = new List<int>();

                            using (var cmd = new SqlCommand(@"
                                SELECT ListingID, EstimatedPrice
                                FROM WasteManagement.WasteListing
                                WHERE ListingID IN (" + string.Join(",", listingIds) + @")
                                AND CitizenID = @CitizenID
                                AND Status = 'Pending'", connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@CitizenID", citizenId);
                                using (var reader = cmd.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        validListings.Add(reader.GetInt32(0));
                                        totalAmount += reader.IsDBNull(1) ? 0 : reader.GetDecimal(1);
                                    }
                                }
                            }

                            if (validListings.Count == 0)
                            {
                                message = "No valid pending listings found";
                                transaction.Rollback();
                                return false;
                            }

                            // Create transaction record
                            int transactionId;
                            string verificationCode = "VER-" + Guid.NewGuid().ToString();

                            using (var cmd = new SqlCommand(@"
                                INSERT INTO WasteManagement.TransactionRecord
                                (CitizenID, TotalAmount, PaymentStatus, PaymentMethod, TransactionDate, VerificationCode)
                                VALUES (@CitizenID, @TotalAmount, 'Pending', 'Digital Wallet', GETDATE(), @VerificationCode);
                                SELECT CAST(SCOPE_IDENTITY() AS INT);", connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@CitizenID", citizenId);
                                cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                                cmd.Parameters.AddWithValue("@VerificationCode", verificationCode);

                                transactionId = (int)cmd.ExecuteScalar();
                            }

                            // Update listings
                            using (var cmd = new SqlCommand(@"
                                UPDATE WasteManagement.WasteListing
                                SET TransactionID = @TransactionID
                                WHERE ListingID IN (" + string.Join(",", validListings) + ")", connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@TransactionID", transactionId);
                                cmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            message = $"Published {validListings.Count} listings successfully. Verification Code: {verificationCode}";
                            return true;
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            message = $"Error: {ex.Message}";
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public List<WasteListing> GetMyListings(string citizenId)
        {
            return _context.WasteListings
                .Include(wl => wl.Category)
                .Where(wl => wl.CitizenId == citizenId)
                .OrderByDescending(wl => wl.CreatedAt)
                .ToList();
        }

        public List<VwTransactionSummary> GetMyTransactions(string citizenId)
        {
            return _context.VwTransactionSummaries
                .Where(vt => vt.CitizenName != null)
                .ToList();
        }

        public VwCitizenProfile GetProfile(string citizenId)
        {
            return _context.VwCitizenProfiles
                .FirstOrDefault(vcp => vcp.CitizenId == citizenId);
        }

        private string HashPassword(string password)
        {
            using (System.Security.Cryptography.SHA256 sha256 = System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }
}
