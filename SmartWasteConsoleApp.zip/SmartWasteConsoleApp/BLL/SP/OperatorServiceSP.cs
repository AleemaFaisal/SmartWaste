using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Data;
using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.SP
{
    public class OperatorServiceSP : IOperatorService
    {
        private readonly SmartWasteDbContext _context;
        private readonly string _connectionString;

        public OperatorServiceSP()
        {
            _context = new SmartWasteDbContext();
            _connectionString = "Server=localhost;Database=SmartWasteDB;User Id=sa;Password=mak@1234;TrustServerCertificate=True;Connection Timeout=60;Pooling=true;Max Pool Size=100;MultipleActiveResultSets=True;";
        }

        public List<VwOperatorCollectionPoint> GetCollectionPoints(string operatorId)
        {
            // Use view directly
            return _context.VwOperatorCollectionPoints
                .Where(vcp => vcp.OperatorId == operatorId)
                .ToList();
        }

        public bool PerformCollection(string operatorId, int listingId, decimal collectedWeight, int warehouseId, out string message)
        {
            // This operation doesn't have a specific SP, use ADO.NET
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Get listing info
                            int categoryId;
                            int? transactionId;
                            DateTime createdAt;

                            using (var cmd = new SqlCommand(@"
                                SELECT CategoryID, TransactionID, CreatedAt
                                FROM WasteManagement.WasteListing
                                WHERE ListingID = @ListingID AND Status = 'Pending'", connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@ListingID", listingId);
                                using (var reader = cmd.ExecuteReader())
                                {
                                    if (!reader.Read())
                                    {
                                        message = "Listing not found or not in pending status";
                                        transaction.Rollback();
                                        return false;
                                    }
                                    categoryId = reader.GetInt32(0);
                                    transactionId = reader.IsDBNull(1) ? null : reader.GetInt32(1);
                                    createdAt = reader.GetDateTime(2);
                                }
                            }

                            // Check warehouse capacity using function
                            using (var cmd = new SqlCommand(@"
                                SELECT WasteManagement.fn_CheckWarehouseCapacity(@WarehouseID, @AdditionalWeight)",
                                connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@WarehouseID", warehouseId);
                                cmd.Parameters.AddWithValue("@AdditionalWeight", (double)collectedWeight);

                                var capacityCheck = cmd.ExecuteScalar();
                                if (capacityCheck == null || !(bool)capacityCheck)
                                {
                                    message = "Warehouse capacity exceeded";
                                    transaction.Rollback();
                                    return false;
                                }
                            }

                            // Insert collection
                            using (var cmd = new SqlCommand(@"
                                INSERT INTO WasteManagement.Collection
                                (OperatorID, ListingID, CollectedDate, CollectedWeight, IsVerified, WarehouseID)
                                VALUES (@OperatorID, @ListingID, GETDATE(), @CollectedWeight, 1, @WarehouseID)",
                                connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@OperatorID", operatorId);
                                cmd.Parameters.AddWithValue("@ListingID", listingId);
                                cmd.Parameters.AddWithValue("@CollectedWeight", collectedWeight);
                                cmd.Parameters.AddWithValue("@WarehouseID", warehouseId);
                                cmd.ExecuteNonQuery();
                            }

                            // Update listing status (trigger handles this but we can do it explicitly)
                            using (var cmd = new SqlCommand(@"
                                UPDATE WasteManagement.WasteListing
                                SET Status = 'Collected'
                                WHERE ListingID = @ListingID", connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@ListingID", listingId);
                                cmd.ExecuteNonQuery();
                            }

                            // Update/Insert warehouse stock
                            using (var cmd = new SqlCommand(@"
                                IF EXISTS (SELECT 1 FROM WasteManagement.WarehouseStock
                                          WHERE WarehouseID = @WarehouseID AND CategoryID = @CategoryID)
                                BEGIN
                                    UPDATE WasteManagement.WarehouseStock
                                    SET CurrentWeight = CurrentWeight + @Weight,
                                        LastUpdated = GETDATE()
                                    WHERE WarehouseID = @WarehouseID AND CategoryID = @CategoryID
                                END
                                ELSE
                                BEGIN
                                    INSERT INTO WasteManagement.WarehouseStock
                                    (WarehouseID, CategoryID, CurrentWeight, LastUpdated)
                                    VALUES (@WarehouseID, @CategoryID, @Weight, GETDATE())
                                END", connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@WarehouseID", warehouseId);
                                cmd.Parameters.AddWithValue("@CategoryID", categoryId);
                                cmd.Parameters.AddWithValue("@Weight", (double)collectedWeight);
                                cmd.ExecuteNonQuery();
                            }

                            // Update transaction status if exists
                            if (transactionId.HasValue)
                            {
                                using (var cmd = new SqlCommand(@"
                                    UPDATE WasteManagement.TransactionRecord
                                    SET PaymentStatus = 'Completed', OperatorID = @OperatorID
                                    WHERE TransactionID = @TransactionID", connection, transaction))
                                {
                                    cmd.Parameters.AddWithValue("@OperatorID", operatorId);
                                    cmd.Parameters.AddWithValue("@TransactionID", transactionId.Value);
                                    cmd.ExecuteNonQuery();
                                }
                            }

                            transaction.Commit();
                            message = "Collection performed successfully";
                            return true;
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            message = $"Error: {ex.Message}";
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public VwOperatorPerformance GetMyPerformance(string operatorId)
        {
            // Use stored procedure
            try
            {
                var performances = _context.VwOperatorPerformances
                    .FromSqlRaw("EXEC WasteManagement.sp_OperatorPerformance")
                    .ToList();

                return performances.FirstOrDefault(p => p.OperatorId == operatorId);
            }
            catch
            {
                return _context.VwOperatorPerformances
                    .FirstOrDefault(vop => vop.OperatorId == operatorId);
            }
        }

        public Route GetMyRoute(string operatorId)
        {
            var operator_ = _context.Operators
                .Include(o => o.Route)
                    .ThenInclude(r => r.Area)
                .FirstOrDefault(o => o.OperatorId == operatorId);

            return operator_?.Route;
        }

        public Operator GetProfile(string operatorId)
        {
            return _context.Operators
                .Include(o => o.Route)
                .Include(o => o.Warehouse)
                .FirstOrDefault(o => o.OperatorId == operatorId);
        }

        public bool UpdateStatus(string operatorId, string status, out string message)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(@"
                        UPDATE WasteManagement.Operator
                        SET Status = @Status
                        WHERE OperatorID = @OperatorID", connection))
                    {
                        command.Parameters.AddWithValue("@OperatorID", operatorId);
                        command.Parameters.AddWithValue("@Status", status);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            message = $"Status updated to {status}";
                            return true;
                        }
                        else
                        {
                            message = "Operator not found";
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }
    }
}
