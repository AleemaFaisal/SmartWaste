using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Data;
using SmartWasteConsoleApp.Models;
using System.Security.Cryptography;
using System.Text;

namespace SmartWasteConsoleApp.BLL.SP
{
    public class AuthServiceSP : IAuthService
    {
        private readonly SmartWasteDbContext _context;
        private readonly string _connectionString;

        public AuthServiceSP()
        {
            _context = new SmartWasteDbContext();
            _connectionString = "Server=localhost;Database=SmartWasteDB;User Id=sa;Password=mak@1234;TrustServerCertificate=True;Connection Timeout=60;Pooling=true;Max Pool Size=100;MultipleActiveResultSets=True;";
        }

        public (bool success, User user, string roleName, string message) AuthenticateUser(string userId, string password)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(@"
                        SELECT u.UserID, u.PasswordHash, u.RoleID, u.CreatedAt, r.RoleName
                        FROM WasteManagement.Users u
                        INNER JOIN WasteManagement.UserRole r ON u.RoleID = r.RoleID
                        WHERE u.UserID = @UserID", connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);

                        using (var reader = command.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                return (false, null!, "", "User not found. Please check your CNIC.");
                            }

                            string storedHash = reader.GetString(1);
                            int roleId = reader.GetInt32(2);
                            DateTime createdAt = reader.GetDateTime(3);
                            string roleName = reader.GetString(4);

                            // Verify password
                            if (!VerifyPassword(password, storedHash))
                            {
                                return (false, null!, "", "Invalid password. Please try again.");
                            }

                            // Create user object
                            var user = new User
                            {
                                UserId = userId,
                                PasswordHash = storedHash,
                                RoleId = roleId,
                                CreatedAt = createdAt
                            };

                            return (true, user, roleName, "Authentication successful");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return (false, null!, "", $"Error during authentication: {ex.Message}");
            }
        }

        public bool VerifyPassword(string password, string storedHash)
        {
            // Hash the input password
            string hashedInput = HashPassword(password);

            // Compare with stored hash
            return hashedInput == storedHash;
        }

        public string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }
}
