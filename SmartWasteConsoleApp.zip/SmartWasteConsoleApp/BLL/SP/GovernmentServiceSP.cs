using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.Data;
using SmartWasteConsoleApp.Models;

namespace SmartWasteConsoleApp.BLL.SP
{
    public class GovernmentServiceSP : IGovernmentService
    {
        private readonly SmartWasteDbContext _context;
        private readonly string _connectionString;

        public GovernmentServiceSP()
        {
            _context = new SmartWasteDbContext();
            _connectionString = "Server=localhost;Database=SmartWasteDB;User Id=sa;Password=mak@1234;TrustServerCertificate=True;Connection Timeout=60;Pooling=true;Max Pool Size=100;MultipleActiveResultSets=True;";
        }

        // Warehouse Analytics
        public List<VwWarehouseInventory> GetWarehouseInventory()
        {
            return _context.VwWarehouseInventories.ToList();
        }

        public VwWarehouseInventory GetWarehouseById(int warehouseId)
        {
            return _context.VwWarehouseInventories
                .FirstOrDefault(vwi => vwi.WarehouseId == warehouseId);
        }

        public List<VwLatestStockByCategory> GetStockByCategory()
        {
            return _context.VwLatestStockByCategories.ToList();
        }

        // Reports and Analytics using Stored Procedures
        public List<dynamic> GetHighYieldAreas()
        {
            try
            {
                var results = new List<dynamic>();
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand("WasteManagement.sp_AnalyzeHighYieldAreas", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                results.Add(new
                                {
                                    AreaId = reader.GetInt32(0),
                                    AreaName = reader.GetString(1),
                                    City = reader.GetString(2),
                                    TotalListings = reader.GetInt32(3),
                                    TotalWeight = reader.GetDouble(4),
                                    TotalRevenue = reader.GetDouble(5),
                                    RevenueRank = reader.GetInt64(6)
                                });
                            }
                        }
                    }
                }
                return results;
            }
            catch
            {
                return new List<dynamic>();
            }
        }

        public List<VwOperatorPerformance> GetOperatorPerformance()
        {
            try
            {
                return _context.VwOperatorPerformances
                    .FromSqlRaw("EXEC WasteManagement.sp_OperatorPerformance")
                    .ToList();
            }
            catch
            {
                return _context.VwOperatorPerformances
                    .OrderByDescending(vop => vop.TotalPickups)
                    .ToList();
            }
        }

        public List<VwPartitionStatistic> GetPartitionStatistics()
        {
            try
            {
                return _context.VwPartitionStatistics
                    .FromSqlRaw("EXEC WasteManagement.sp_GetPartitionStatus")
                    .ToList();
            }
            catch
            {
                return _context.VwPartitionStatistics.ToList();
            }
        }

        // Manage Pricing and Categories
        public List<Category> GetAllCategories()
        {
            return _context.Categories.ToList();
        }

        public bool CreateCategory(string categoryName, decimal basePricePerKg, string description, out string message)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(@"
                        INSERT INTO WasteManagement.Category (CategoryName, BasePricePerKg, Description)
                        VALUES (@CategoryName, @BasePricePerKg, @Description)", connection))
                    {
                        command.Parameters.AddWithValue("@CategoryName", categoryName);
                        command.Parameters.AddWithValue("@BasePricePerKg", basePricePerKg);
                        command.Parameters.AddWithValue("@Description", description ?? (object)DBNull.Value);

                        command.ExecuteNonQuery();
                        message = "Category created successfully";
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public bool UpdateCategoryPrice(int categoryId, decimal newPrice, out string message)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(@"
                        UPDATE WasteManagement.Category
                        SET BasePricePerKg = @NewPrice
                        WHERE CategoryID = @CategoryID", connection))
                    {
                        command.Parameters.AddWithValue("@CategoryID", categoryId);
                        command.Parameters.AddWithValue("@NewPrice", newPrice);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            message = "Category price updated successfully";
                            return true;
                        }
                        else
                        {
                            message = "Category not found";
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public bool DeleteCategory(int categoryId, out string message)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(@"
                        DELETE FROM WasteManagement.Category
                        WHERE CategoryID = @CategoryID", connection))
                    {
                        command.Parameters.AddWithValue("@CategoryID", categoryId);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            message = "Category deleted successfully";
                            return true;
                        }
                        else
                        {
                            message = "Category not found";
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        // Manage Operators using Stored Procedures
        public bool CreateOperator(string cnic, string fullName, string phoneNumber, out string message)
        {
            message = string.Empty;

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand("WasteManagement.sp_CreateOperator", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@CNIC", cnic);
                        command.Parameters.AddWithValue("@Name", fullName);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);

                        var resultMessageParam = new SqlParameter("@ResultMessage", System.Data.SqlDbType.VarChar, 255)
                        {
                            Direction = System.Data.ParameterDirection.Output
                        };
                        command.Parameters.Add(resultMessageParam);

                        var returnValue = new SqlParameter()
                        {
                            Direction = System.Data.ParameterDirection.ReturnValue
                        };
                        command.Parameters.Add(returnValue);

                        command.ExecuteNonQuery();

                        message = resultMessageParam.Value?.ToString() ?? "";
                        int result = (int)returnValue.Value;

                        return result == 0;
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public bool AssignOperatorToRoute(string operatorId, int routeId, int warehouseId, out string message)
        {
            message = string.Empty;

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand("WasteManagement.sp_AssignOperatorToRoute", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@OperatorID", operatorId);
                        command.Parameters.AddWithValue("@RouteID", routeId);
                        command.Parameters.AddWithValue("@WarehouseID", warehouseId);

                        command.ExecuteNonQuery();
                        message = "Operator assigned to route successfully";
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public bool DeactivateOperator(string operatorId, out string message)
        {
            message = string.Empty;

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand("WasteManagement.sp_DeactivateOperator", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@OperatorID", operatorId);

                        command.ExecuteNonQuery();
                        message = "Operator deactivated successfully";
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        public List<Operator> GetAllOperators()
        {
            return _context.Operators
                .Include(o => o.Route)
                .Include(o => o.Warehouse)
                .ToList();
        }

        // Review Complaints
        public List<VwActiveComplaint> GetActiveComplaints()
        {
            return _context.VwActiveComplaints.ToList();
        }

        public List<Complaint> GetAllComplaints()
        {
            return _context.Complaints
                .Include(c => c.Citizen)
                .Include(c => c.Operator)
                .OrderByDescending(c => c.CreatedAt)
                .ToList();
        }

        public bool UpdateComplaintStatus(int complaintId, string status, out string message)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(@"
                        UPDATE WasteManagement.Complaint
                        SET Status = @Status
                        WHERE ComplaintID = @ComplaintID", connection))
                    {
                        command.Parameters.AddWithValue("@ComplaintID", complaintId);
                        command.Parameters.AddWithValue("@Status", status);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            message = $"Complaint status updated to {status}";
                            return true;
                        }
                        else
                        {
                            message = "Complaint not found";
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                message = $"Error: {ex.Message}";
                return false;
            }
        }

        // Helper methods
        public List<Area> GetAllAreas()
        {
            return _context.Areas.ToList();
        }

        public List<Route> GetAllRoutes()
        {
            return _context.Routes
                .Include(r => r.Area)
                .ToList();
        }

        public List<Warehouse> GetAllWarehouses()
        {
            return _context.Warehouses
                .Include(w => w.Area)
                .ToList();
        }
    }
}
