using SmartWasteConsoleApp.BLL.EF;
using SmartWasteConsoleApp.BLL.Interfaces;
using SmartWasteConsoleApp.BLL.SP;

namespace SmartWasteConsoleApp.Factory
{
    public enum ImplementationType
    {
        EntityFramework,
        StoredProcedure
    }

    public static class ServiceFactory
    {
        private static ImplementationType _currentImplementation = ImplementationType.EntityFramework;

        public static ImplementationType CurrentImplementation
        {
            get => _currentImplementation;
            set => _currentImplementation = value;
        }

        public static ICitizenService GetCitizenService()
        {
            return _currentImplementation == ImplementationType.EntityFramework
                ? new CitizenServiceEF()
                : new CitizenServiceSP();
        }

        public static IOperatorService GetOperatorService()
        {
            return _currentImplementation == ImplementationType.EntityFramework
                ? new OperatorServiceEF()
                : new OperatorServiceSP();
        }

        public static IGovernmentService GetGovernmentService()
        {
            return _currentImplementation == ImplementationType.EntityFramework
                ? new GovernmentServiceEF()
                : new GovernmentServiceSP();
        }

        public static IAuthService GetAuthService()
        {
            return _currentImplementation == ImplementationType.EntityFramework
                ? new AuthServiceEF()
                : new AuthServiceSP();
        }

        public static string GetCurrentImplementationName()
        {
            return _currentImplementation == ImplementationType.EntityFramework
                ? "Entity Framework (LINQ)"
                : "Stored Procedures";
        }
    }
}
