using System;
using Microsoft.Data.SqlClient;

namespace SmartWasteConsoleApp
{
    public class QuickDBTest
    {
        public static void TestConnection()
        {
            string connectionString = "Server=localhost;Database=SmartWasteDB;User Id=sa;Password=mak@1234;TrustServerCertificate=True;Connection Timeout=10;";

            Console.WriteLine("=== SQL Server Quick Test ===\n");

            try
            {
                Console.WriteLine("Step 1: Opening connection...");
                var startTime = DateTime.Now;

                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var connectTime = (DateTime.Now - startTime).TotalMilliseconds;
                    Console.WriteLine($"✓ Connected in {connectTime}ms\n");

                    // Test 1: Simple query
                    Console.WriteLine("Step 2: Running simple query...");
                    startTime = DateTime.Now;
                    using (var cmd = new SqlCommand("SELECT GETDATE()", connection))
                    {
                        var result = cmd.ExecuteScalar();
                        var queryTime = (DateTime.Now - startTime).TotalMilliseconds;
                        Console.WriteLine($"✓ Query executed in {queryTime}ms");
                        Console.WriteLine($"   Server time: {result}\n");
                    }

                    // Test 2: Check if Users table exists and has data
                    Console.WriteLine("Step 3: Checking Users table...");
                    startTime = DateTime.Now;
                    using (var cmd = new SqlCommand("SELECT COUNT(*) FROM WasteManagement.Users", connection))
                    {
                        var count = (int)cmd.ExecuteScalar();
                        var queryTime = (DateTime.Now - startTime).TotalMilliseconds;
                        Console.WriteLine($"✓ Query executed in {queryTime}ms");
                        Console.WriteLine($"   User count: {count}\n");

                        if (count == 0)
                        {
                            Console.WriteLine("⚠ WARNING: No users found in database!");
                            Console.WriteLine("   You need to run the population scripts first.");
                        }
                    }

                    // Test 3: Check specific user
                    Console.WriteLine("Step 4: Looking for test admin user...");
                    startTime = DateTime.Now;
                    using (var cmd = new SqlCommand(
                        "SELECT UserID, PasswordHash FROM WasteManagement.Users WHERE UserID = '12345-6789012-3'",
                        connection))
                    {
                        using (var reader = cmd.ExecuteReader())
                        {
                            var queryTime = (DateTime.Now - startTime).TotalMilliseconds;
                            Console.WriteLine($"✓ Query executed in {queryTime}ms");

                            if (reader.Read())
                            {
                                string userId = reader.GetString(0);
                                string hash = reader.GetString(1);
                                Console.WriteLine($"   Found user: {userId}");
                                Console.WriteLine($"   Password hash: {hash.Substring(0, Math.Min(20, hash.Length))}...");
                            }
                            else
                            {
                                Console.WriteLine("   ✗ Admin user NOT FOUND!");
                                Console.WriteLine("   Run FixPasswords.sql to create test users");
                            }
                        }
                    }
                }

                Console.WriteLine("\n=== All Tests Passed ===");
            }
            catch (SqlException ex)
            {
                Console.WriteLine($"\n✗ SQL Error: {ex.Message}");
                Console.WriteLine($"   Error Number: {ex.Number}");
                Console.WriteLine($"   Server: {ex.Server}");

                if (ex.Number == -1 || ex.Number == -2)
                {
                    Console.WriteLine("\n⚠ CONNECTION TIMEOUT - Possible causes:");
                    Console.WriteLine("   1. SQL Server service not running");
                    Console.WriteLine("   2. Firewall blocking connection");
                    Console.WriteLine("   3. Wrong server name (should be 'localhost')");
                }
                else if (ex.Number == 4060)
                {
                    Console.WriteLine("\n⚠ DATABASE NOT FOUND");
                    Console.WriteLine("   Run the db.sql script to create SmartWasteDB");
                }
                else if (ex.Number == 18456)
                {
                    Console.WriteLine("\n⚠ LOGIN FAILED");
                    Console.WriteLine("   Check SQL Server authentication settings");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n✗ Unexpected Error: {ex.Message}");
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
