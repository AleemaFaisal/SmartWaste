﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class VwTransactionSummary
{
    public int TransactionId { get; set; }

    public string CitizenName { get; set; } = null!;

    public decimal TotalAmount { get; set; }

    public string? PaymentStatus { get; set; }

    public DateTime TransactionDate { get; set; }

    public int? ItemCount { get; set; }

    public decimal? TotalWeight { get; set; }

    public string? OperatorName { get; set; }
}
