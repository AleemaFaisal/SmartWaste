﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class User
{
    public string UserId { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public int RoleId { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual Citizen? Citizen { get; set; }

    public virtual Operator? Operator { get; set; }

    public virtual UserRole Role { get; set; } = null!;
}
