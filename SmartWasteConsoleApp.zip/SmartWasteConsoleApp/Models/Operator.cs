﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class Operator
{
    public string OperatorId { get; set; } = null!;

    public string FullName { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public int? RouteId { get; set; }

    public int? WarehouseId { get; set; }

    public string? Status { get; set; }

    public virtual ICollection<Collection> Collections { get; set; } = new List<Collection>();

    public virtual ICollection<Complaint> Complaints { get; set; } = new List<Complaint>();

    public virtual User OperatorNavigation { get; set; } = null!;

    public virtual Route? Route { get; set; }

    public virtual ICollection<TransactionRecord> TransactionRecords { get; set; } = new List<TransactionRecord>();

    public virtual Warehouse? Warehouse { get; set; }
}
