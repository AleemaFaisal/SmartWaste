﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class VwWarehouseInventory
{
    public int WarehouseId { get; set; }

    public string WarehouseName { get; set; } = null!;

    public string AreaName { get; set; } = null!;

    public string City { get; set; } = null!;

    public double Capacity { get; set; }

    public double? CurrentInventory { get; set; }

    public double? CapacityUsedPercent { get; set; }

    public double? AvailableCapacity { get; set; }

    public int? CategoryCount { get; set; }
}
