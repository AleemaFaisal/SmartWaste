﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class TransactionRecord
{
    public int TransactionId { get; set; }

    public string CitizenId { get; set; } = null!;

    public string? OperatorId { get; set; }

    public decimal TotalAmount { get; set; }

    public string? PaymentStatus { get; set; }

    public string? PaymentMethod { get; set; }

    public DateTime TransactionDate { get; set; }

    public string? VerificationCode { get; set; }

    public virtual Citizen Citizen { get; set; } = null!;

    public virtual Operator? Operator { get; set; }
}
