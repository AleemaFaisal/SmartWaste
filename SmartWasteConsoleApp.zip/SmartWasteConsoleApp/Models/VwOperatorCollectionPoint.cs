﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class VwOperatorCollectionPoint
{
    public string OperatorId { get; set; } = null!;

    public string OperatorName { get; set; } = null!;

    public int RouteId { get; set; }

    public string RouteName { get; set; } = null!;

    public int ListingId { get; set; }

    public string CitizenId { get; set; } = null!;

    public string CitizenName { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public string? Address { get; set; }

    public string AreaName { get; set; } = null!;

    public string CategoryName { get; set; } = null!;

    public decimal Weight { get; set; }

    public decimal? EstimatedPrice { get; set; }

    public string? Status { get; set; }

    public string? VerificationCode { get; set; }
}
