﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class Collection
{
    public int CollectionId { get; set; }

    public string OperatorId { get; set; } = null!;

    public int ListingId { get; set; }

    public DateTime CollectedDate { get; set; }

    public decimal CollectedWeight { get; set; }

    public string? PhotoProof { get; set; }

    public bool? IsVerified { get; set; }

    public int WarehouseId { get; set; }

    public virtual Operator Operator { get; set; } = null!;

    public virtual Warehouse Warehouse { get; set; } = null!;
}
