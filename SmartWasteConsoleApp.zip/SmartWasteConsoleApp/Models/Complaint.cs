﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class Complaint
{
    public int ComplaintId { get; set; }

    public string CitizenId { get; set; } = null!;

    public string? OperatorId { get; set; }

    public string ComplaintType { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string? Status { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual Citizen Citizen { get; set; } = null!;

    public virtual Operator? Operator { get; set; }
}
