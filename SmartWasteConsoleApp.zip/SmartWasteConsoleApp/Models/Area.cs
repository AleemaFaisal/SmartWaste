﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class Area
{
    public int AreaId { get; set; }

    public string AreaName { get; set; } = null!;

    public string City { get; set; } = null!;

    public virtual ICollection<Citizen> Citizens { get; set; } = new List<Citizen>();

    public virtual ICollection<Route> Routes { get; set; } = new List<Route>();

    public virtual ICollection<Warehouse> Warehouses { get; set; } = new List<Warehouse>();
}
