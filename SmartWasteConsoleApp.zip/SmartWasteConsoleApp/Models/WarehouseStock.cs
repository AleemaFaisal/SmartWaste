﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class WarehouseStock
{
    public int WarehouseId { get; set; }

    public int CategoryId { get; set; }

    public double CurrentWeight { get; set; }

    public DateTime? LastUpdated { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual Warehouse Warehouse { get; set; } = null!;
}
