﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class VwPartitionStatistic
{
    public string? TableName { get; set; }

    public int PartitionNumber { get; set; }

    public string? RangeBoundary { get; set; }

    public long? RecordCount { get; set; }

    public decimal? SizeMb { get; set; }
}
