﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class Citizen
{
    public string CitizenId { get; set; } = null!;

    public string FullName { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public int AreaId { get; set; }

    public string? Address { get; set; }

    public virtual Area Area { get; set; } = null!;

    public virtual User CitizenNavigation { get; set; } = null!;

    public virtual ICollection<Complaint> Complaints { get; set; } = new List<Complaint>();

    public virtual ICollection<TransactionRecord> TransactionRecords { get; set; } = new List<TransactionRecord>();

    public virtual ICollection<WasteListing> WasteListings { get; set; } = new List<WasteListing>();
}
