﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class Warehouse
{
    public int WarehouseId { get; set; }

    public string WarehouseName { get; set; } = null!;

    public int AreaId { get; set; }

    public string Address { get; set; } = null!;

    public double Capacity { get; set; }

    public double? CurrentInventory { get; set; }

    public virtual Area Area { get; set; } = null!;

    public virtual ICollection<Collection> Collections { get; set; } = new List<Collection>();

    public virtual ICollection<Operator> Operators { get; set; } = new List<Operator>();

    public virtual ICollection<WarehouseStock> WarehouseStocks { get; set; } = new List<WarehouseStock>();
}
