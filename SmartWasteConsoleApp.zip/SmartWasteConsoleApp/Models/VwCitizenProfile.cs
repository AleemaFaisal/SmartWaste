﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class VwCitizenProfile
{
    public string CitizenId { get; set; } = null!;

    public string FullName { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public string? Address { get; set; }

    public int AreaId { get; set; }

    public string AreaName { get; set; } = null!;

    public string City { get; set; } = null!;

    public DateTime? MemberSince { get; set; }
}
