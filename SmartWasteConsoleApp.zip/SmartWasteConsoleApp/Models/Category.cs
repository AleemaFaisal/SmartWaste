﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class Category
{
    public int CategoryId { get; set; }

    public string CategoryName { get; set; } = null!;

    public decimal BasePricePerKg { get; set; }

    public string? Description { get; set; }

    public virtual ICollection<WarehouseStock> WarehouseStocks { get; set; } = new List<WarehouseStock>();

    public virtual ICollection<WasteListing> WasteListings { get; set; } = new List<WasteListing>();
}
