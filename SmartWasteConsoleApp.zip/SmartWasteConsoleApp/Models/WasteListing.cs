﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class WasteListing
{
    public int ListingId { get; set; }

    public string CitizenId { get; set; } = null!;

    public int CategoryId { get; set; }

    public decimal Weight { get; set; }

    public string? Status { get; set; }

    public decimal? EstimatedPrice { get; set; }

    public int? TransactionId { get; set; }

    public DateTime CreatedAt { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual Citizen Citizen { get; set; } = null!;
}
