﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class VwLatestStockByCategory
{
    public int WarehouseId { get; set; }

    public int CategoryId { get; set; }

    public string CategoryName { get; set; } = null!;

    public DateOnly? StockDate { get; set; }

    public double CurrentWeight { get; set; }
}
