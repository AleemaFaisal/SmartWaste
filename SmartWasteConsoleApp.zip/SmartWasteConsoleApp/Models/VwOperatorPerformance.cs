﻿using System;
using System.Collections.Generic;

namespace SmartWasteConsoleApp.Models;

public partial class VwOperatorPerformance
{
    public string OperatorId { get; set; } = null!;

    public string FullName { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public int? RouteId { get; set; }

    public int? WarehouseId { get; set; }

    public int? TotalPickups { get; set; }

    public decimal? TotalCollectedWeight { get; set; }

    public decimal? TotalCollectedAmount { get; set; }
}
