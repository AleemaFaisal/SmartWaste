# Smart Waste Management System - Test Credentials

## Setup Instructions

1. **Run the SQL script to create test accounts:**
run the script manually in SQL Server Management Studio (SSMS)

2. **Start the application:**
   ```bash
   cd SmartWasteConsoleApp
   dotnet run
   ```

---

## 🔑 Test Account Credentials

### Government Regulator / Admin Portal

| CNIC | Password | Role |
|------|----------|------|
| `12345-6789012-3` | `admin123` | Admin |

**Use this to access:**
- Warehouse Analytics
- High Yield Area Analysis
- Operator Performance Reports
- Partition Statistics
- Category Management (CRUD)
- Operator Management
- Complaints Review

---

### Operator Portal

| CNIC | Password | Name |
|------|----------|------|
| `42000-0300001-0` | `operator123` | Operator 1 |
| `42000-0300002-1` | `operator123` | Operator 2 |
| `42000-0300003-2` | `operator123` | Operator 3 |
| `42000-0300004-3` | `operator123` | Operator 4 |
| `42000-0300005-4` | `operator123` | Operator 5 |

**Use this to access:**
- Collection Points on Route
- Perform Collections
- View Performance Metrics
- Update Operator Status

---

### Citizen Portal

| CNIC | Password | Name |
|------|----------|------|
| `35201-0000001-0` | `citizen123` | Citizen 1 |
| `35202-0000002-1` | `citizen123` | Citizen 2 |
| `35203-0000003-2` | `citizen123` | Citizen 3 |
| `35204-0000004-3` | `citizen123` | Citizen 4 |
| `35205-0000005-4` | `citizen123` | Citizen 5 |

**Use this to access:**
- Create Waste Listings
- Publish Listings for Pickup
- View My Listings
- Price Estimation
- View Transactions
- Profile Management

---

## Test Scenarios

### **Scenario 1: Complete Citizen Flow**
1. Login as Citizen: `35201-0000001-0` / `citizen123`
2. Create a waste listing (e.g., 5kg of Plastic)
3. View the estimated price
4. Publish the listing to request pickup

### **Scenario 2: Operator Collection Flow**
1. Login as Operator: `42000-0300001-0` / `oppass1`
2. View collection points on your route
3. Select a pending listing from a citizen
4. Perform collection (enter listing ID, weight, warehouse)
5. View your performance metrics

### **Scenario 3: Government Analytics**
1. Login as Admin: `12345-6789012-3` / `admin123`
2. View warehouse inventory status
3. Analyze high-yield areas (uses CTE-based stored procedure)
4. View operator performance rankings
5. Check partition statistics
6. Create/Update waste categories
7. Manage operators (create, assign to routes)

### **Scenario 4: Test Both Implementations**
1. From main menu -> Switch BLL Implementation
2. Choose "Stored Procedures"
3. Perform any operation
4. Switch back to "Entity Framework (LINQ)"
5. Perform the same operation
6. Verify both work correctly

---

## Switching Between BLL Implementations

The Factory Pattern allows runtime switching:

1. **From Main Menu**: Select option "5. Switch BLL Implementation"
2. **Choose**:
   - `1` for Entity Framework (LINQ)
   - `2` for Stored Procedures
3. **Confirmation**: You'll see which implementation is active at the top of each screen

Both implementations use:
- **EF Version**: LINQ queries with Entity Framework
- **SP Version**: Direct stored procedure calls via ADO.NET

---

## 📝 Additional Notes

- **Default Warehouse**: Warehouse ID 1-5 are available for collections
- **Routes**: Operators are pre-assigned to routes 1-10
- **Categories**: Plastic, Paper, Metal, Glass, E-Waste, Organic
- **Price Calculation**: Uses `fn_CalculatePrice` UDF
- **Triggers**: Automatically update inventory and listing status
- **Views**: All 8 database views are accessible through the UI
- **CTEs**: Used in high-yield analysis and operator performance SPs

