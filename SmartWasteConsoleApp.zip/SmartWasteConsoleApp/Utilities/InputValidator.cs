namespace SmartWasteConsoleApp.Utilities
{
    public static class InputValidator
    {
        public static bool ValidateCNIC(string cnic)
        {
            if (string.IsNullOrEmpty(cnic)) return false;
            var parts = cnic.Split('-');
            return parts.Length == 3 &&
                   parts[0].Length == 5 && parts[0].All(char.IsDigit) &&
                   parts[1].Length == 7 && parts[1].All(char.IsDigit) &&
                   parts[2].Length == 1 && parts[2].All(char.IsDigit);
        }

        public static bool ValidatePhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrEmpty(phoneNumber)) return false;
            // Simple validation: should contain only digits, hyphens, and plus
            return phoneNumber.All(c => char.IsDigit(c) || c == '-' || c == '+');
        }

        public static bool ValidatePositiveDecimal(string input, out decimal value)
        {
            if (decimal.TryParse(input, out value))
            {
                return value > 0;
            }
            return false;
        }

        public static bool ValidatePositiveInt(string input, out int value)
        {
            if (int.TryParse(input, out value))
            {
                return value > 0;
            }
            return false;
        }

        public static bool ValidateInt(string input, out int value)
        {
            return int.TryParse(input, out value);
        }

        public static bool ValidateNonEmptyString(string input)
        {
            return !string.IsNullOrWhiteSpace(input);
        }
    }
}
