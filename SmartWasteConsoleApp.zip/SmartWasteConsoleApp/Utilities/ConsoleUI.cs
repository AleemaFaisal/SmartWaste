namespace SmartWasteConsoleApp.Utilities
{
    public static class ConsoleUI
    {
        public static void PrintHeader(string title)
        {
            Console.Clear();
            Console.WriteLine("╔════════════════════════════════════════════════════════════╗");
            Console.WriteLine($"║  {title.PadRight(56)}  ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════╝");
            Console.WriteLine();
        }

        public static void PrintSuccess(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"✓ {message}");
            Console.ResetColor();
        }

        public static void PrintError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"✗ {message}");
            Console.ResetColor();
        }

        public static void PrintInfo(string message)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"ℹ {message}");
            Console.ResetColor();
        }

        public static void PrintWarning(string message)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"⚠ {message}");
            Console.ResetColor();
        }

        public static void PrintSeparator()
        {
            Console.WriteLine(new string('-', 60));
        }

        public static void PressAnyKeyToContinue()
        {
            Console.WriteLine();
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        public static string ReadInput(string prompt)
        {
            Console.Write($"{prompt}: ");
            return Console.ReadLine() ?? string.Empty;
        }

        public static string ReadPassword(string prompt)
        {
            Console.Write($"{prompt}: ");
            string password = string.Empty;
            ConsoleKeyInfo key;

            do
            {
                key = Console.ReadKey(true);

                if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                {
                    password += key.KeyChar;
                    Console.Write("*");
                }
                else if (key.Key == ConsoleKey.Backspace && password.Length > 0)
                {
                    password = password.Substring(0, password.Length - 1);
                    Console.Write("\b \b");
                }
            } while (key.Key != ConsoleKey.Enter);

            Console.WriteLine();
            return password;
        }

        public static int ShowMenu(string title, string[] options)
        {
            Console.WriteLine();
            Console.WriteLine($"=== {title} ===");
            Console.WriteLine();

            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {options[i]}");
            }

            Console.WriteLine();
            Console.Write("Select an option: ");

            if (int.TryParse(Console.ReadLine(), out int choice) && choice >= 1 && choice <= options.Length)
            {
                return choice;
            }

            return -1;
        }

        public static void PrintTable<T>(List<T> items, params (string Header, Func<T, string> Accessor)[] columns)
        {
            if (items == null || items.Count == 0)
            {
                PrintWarning("No items to display.");
                return;
            }

            // Calculate column widths
            var widths = new int[columns.Length];
            for (int i = 0; i < columns.Length; i++)
            {
                widths[i] = Math.Max(
                    columns[i].Header.Length,
                    items.Max(item => columns[i].Accessor(item)?.Length ?? 0)
                ) + 2;
            }

            // Print header
            PrintSeparator();
            for (int i = 0; i < columns.Length; i++)
            {
                Console.Write(columns[i].Header.PadRight(widths[i]));
            }
            Console.WriteLine();
            PrintSeparator();

            // Print rows
            foreach (var item in items)
            {
                for (int i = 0; i < columns.Length; i++)
                {
                    var value = columns[i].Accessor(item) ?? "";
                    Console.Write(value.PadRight(widths[i]));
                }
                Console.WriteLine();
            }
            PrintSeparator();
        }
    }
}
